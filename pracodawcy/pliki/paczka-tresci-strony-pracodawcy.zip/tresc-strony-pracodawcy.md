# Treść strony dla pracodawców — Ucz Zawodu

Czysta wersja redakcyjna: bez grafik, nawigacji, przycisków, opisów technicznych i stopki.

PRACODAWCA + SZKOŁA + UCZEŃ

Przewodnik / 2026

# NAUKA ZAWODU W TWOJEJ FIRMIE.

Masz doświadczenie. Możesz przekazać je dalej.  
Zobacz, co dokładnie zrobić, ile zapłacisz i kiedy możesz odzyskać część kosztów.

WYDATEK PRZED REFUNDACJĄ / I ROK

**ok. 872 zł/mies.**

Najpierw firma płaci 738,65 zł brutto ucznia i około 133 zł swoich składek. Okres 1.09–30.11.2026; rzeczywista kwota zależy m.in. od stopy wypadkowej.

OHP ZWRACA W TRAKCIE NAUKI

**po okresie rozliczeniowym**

Najpierw wypłacasz pensję i opłacasz składki. Potem, zgodnie z harmonogramem w umowie z OHP, składasz rozliczenie i otrzymujesz zwrot kwalifikowanej pensji oraz składek. Nie czekasz do końca trzyletniej nauki.

GMINA / DODATKOWO NA KOŃCU

**do 10 824 zł lub 13 394 zł**

To osobne dofinansowanie, niezależne od rozliczeń OHP: 10 824 zł to limit podstawowy, a 13 394 zł dotyczy zawodu spełniającego warunek prognozy MEN. Wniosek składasz po nauce i egzaminie.

TWÓJ BENEFIT PO 3 LATACH

**sprawdzony pracownik**

Zna już Twój zespół, stanowisko, narzędzia i sposób pracy. Jeśli obie strony chcą, możesz kontynuować zatrudnienie bez wdrażania nowej osoby od zera.

DECYZJA W 2 MINUTY

## CO ROBISZ. ILE WYKŁADASZ. CO MOŻESZ ODZYSKAĆ.

Najpierw sprawdzasz warunki ze szkołą i OHP. Potem zatrudniasz młodocianego, wypłacasz wynagrodzenie i składasz rozliczenia. Pieniądze z OHP nie przychodzą z góry, a dofinansowanie z gminy nie jest automatyczne.

01

### Zadzwoń do szkoły i OHP

Podaj zawód, miejscowość i liczbę miejsc. Sprawdź, czy zawód jest w wykazie OHP i kto może być instruktorem. **Zrób to przed podpisaniem umowy.**

02

### Sprawdź instruktora i stanowisko

Zbierz dokumenty kwalifikacji. Jeśli potrzebny jest kurs pedagogiczny, zaplanuj 48 godzin i orientacyjnie 700–1500 zł. Przygotuj BHP, badania, narzędzia i ochronę małoletnich.

03

### Podpisz umowy i zgłoś pracownika

Z młodocianym podpisujesz umowę o pracę w celu przygotowania zawodowego. Osobno składasz wniosek i zawierasz umowę refundacyjną z OHP. Kadry zgłaszają pracownika do ZUS.

04

### Najpierw płacisz z własnych środków

Co miesiąc wypłacasz pensję i opłacasz składki. Zachowujesz listy płac, potwierdzenia przelewów i dokumenty wymagane w umowie z OHP.

05

### Potem rozliczasz dwa rodzaje wsparcia

OHP zwraca kwalifikowane wynagrodzenie i składki po ich opłaceniu i złożeniu rozliczenia. Gmina wypłaca osobne dofinansowanie dopiero po zakończeniu nauki i egzaminie.

PRZYKŁAD / UCZEŃ I ROKU

### Ile pieniędzy?

Kwoty dla okresu 1.09–30.11.2026. Stawka zmienia się wraz z przeciętnym wynagrodzeniem.

CO MIESIĄC FINANSUJESZ

**ok. 872 zł**

Szacowany koszt płacowy pracodawcy: 738,65 zł wynagrodzenia brutto ucznia i około 133 zł składek firmy. Do tego dochodzą faktyczne koszty instruktora, BHP, badań, odzieży i narzędzi.

REFUNDACJA OHP W TRAKCIE NAUKI

**po każdym okresie z umowy**

Najpierw płacisz, następnie składasz rozliczenie zgodnie z harmonogramem umowy. OHP zwraca kwalifikowaną pensję i składki do ustalonego limitu. Nie jest to jednorazowa wypłata po trzech latach.

DOFINANSOWANIE Z GMINY

**do 10 824 zł**

Po 36 miesiącach nauki i egzaminie; do 13 394 zł przy spełnieniu warunku prognozy MEN. Wniosek składasz w ciągu 3 miesięcy od ogłoszenia wyników.

**Czy uczeń jest wtedy „darmowym pracownikiem”?** Po refundacji koszt samego wynagrodzenia może być bardzo niski, ale nie jest to pracownik bez kosztów. Firma nadal finansuje czas instruktora, organizację stanowiska, badania, BHP, odzież, narzędzia oraz ewentualne kwoty nieobjęte umową.  
  
**Czego wsparcie zwykle nie pokrywa?** Czasu instruktora, organizacji stanowiska, badań, odzieży, narzędzi ani części wynagrodzenia ponad limit refundacji. Dlatego przed startem potrzebujesz własnego budżetu na bieżące wypłaty.

CZY TO MA SENS DLA MOJEJ FIRMY?

### Po trzech latach nie zaczynasz od zera.

**To może się opłacać, gdy:** masz fachowca z czasem na uczenie, bezpieczne zadania dla ucznia i chcesz przygotować przyszłego pracownika do sposobu pracy swojej firmy. Po trzech latach uczeń zna już zespół, klientów, stanowisko, narzędzia i standardy pracy. Możesz kontynuować z nim zatrudnienie bez pełnego wdrożenia od początku. Refundacja ogranicza koszt wynagrodzenia, ale pozostanie w firmie zależy od obu stron.

**To nie jest dobry wybór, gdy:** potrzebujesz od razu samodzielnego pracownika, nie masz osoby do codziennego szkolenia albo firma nie może finansować wypłat przed otrzymaniem refundacji.

CO ZYSKUJE FIRMA?

## POZNAJESZ PRACOWNIKA W PRAKTYCE.

To inwestycja, nie darmowa siła robocza. Wymaga czasu instruktora i własnych środków przed refundacją. Dalsza współpraca zależy od obu stron.

↗

### Szkolisz pod swoją firmę

Młodociany przez trzy lata poznaje Twoje narzędzia, standardy, zespół i klientów. Nie uczysz wszystkiego od nowa po zatrudnieniu.

↗

### Sprawdzasz człowieka przed decyzją

Widzisz jego postępy, podejście do pracy i dopasowanie do zespołu. Po nauce obie strony wiedzą, czy chcą pracować dalej.

↗

### Ograniczasz koszt wynagrodzenia

Refundacja OHP może pokryć kwalifikowane wynagrodzenie i składki do limitu z umowy. Osobne dofinansowanie z gminy może przysługiwać po zakończeniu nauki.

KSZTAŁCENIE DUALNE, CZYLI?

## CZĘŚĆ W SZKOLE. CZĘŚĆ W FIRMIE.

Teoria i praktyka tworzą jeden proces. Ten przewodnik dotyczy **umowy o pracę w celu przygotowania zawodowego**. Praktyki szkolne i staż uczniowski mają inne zasady.

A

### Szkoła

Realizuje swoją część kształcenia i współpracuje z firmą.

B

### Firma

Zatrudnia, wynagradza i zapewnia naukę pod opieką instruktora.

MAPA TWOICH PRZYGOTOWAŃ

06 ETAPÓW

## OD CZEGO ZACZĄĆ?

Wybierz temat. Sprawdź warunki.  
Na końcu każdego etapu znajdziesz konkretny następny krok.

01

### Możliwości firmy

Zawód, instruktor i bezpieczne miejsce do nauki.

Twój cel

Sprawdź możliwości firmy.

ETAP 01 / 06

Zacznij od zawodu, osoby szkolącej i miejsca do nauki.

#### Wybierz osobę szkolącą

Instruktor praktycznej nauki zawodu uczy ucznia wykonywania codziennych zadań. Potrzebuje odpowiednich kwalifikacji zawodowych i przygotowania pedagogicznego. Możesz szkolić osobiście albo wyznaczyć uprawnionego pracownika. Samo doświadczenie w branży nie wystarczy.

#### Jak zdobyć przygotowanie pedagogiczne?

Najpierw sprawdź ze szkołą, czy kandydat spełnia wymagania zawodowe z § 10 rozporządzenia. Sam kurs pedagogiczny nie zastępuje dyplomu, świadectwa ani wymaganego doświadczenia zawodowego.

1.  Wybierz kurs pedagogiczny dla instruktorów praktycznej nauki zawodu, którego program zatwierdził kurator oświaty. Skorzystaj z wykazu zatwierdzonych programów Dolnośląskiego Kuratora Oświaty.
2.  Zapytaj organizatora o termin, formę zajęć, dokumenty wymagane przy zapisie i pełną cenę. Zatwierdzenie programu nie oznacza, że każda edycja jest aktualnie prowadzona.
3.  Ukończ kurs i zachowaj zaświadczenie. Ramowy program obejmuje 48 godzin: 40 godzin zajęć oraz 8 godzin praktyki metodycznej.

**Ile czasu i pieniędzy zaplanować?** Zależnie od harmonogramu 48 godzin może oznaczać kilka intensywnych dni albo kilka weekendów, zwykle około 2–6 tygodni kalendarzowych. Ceny ustalają organizatorzy i nie podaje ich urzędowy wykaz. Na etapie planowania przyjmij orientacyjnie około 700–1500 zł, a przed zapisem poproś o aktualną cenę całkowitą. Ten przedział nie jest stawką urzędową ani ofertą konkretnej placówki.

#### Sprawdź stanowisko

Uczeń potrzebuje bezpiecznych narzędzi i zadań zgodnych z programem. Nie każdą czynność dorosłego pracownika można powierzyć młodocianemu. Ograniczenia sprawdź z osobą zajmującą się BHP i lekarzem medycyny pracy.

#### Ustal podział ze szkołą

Omówcie, czego uczeń nauczy się w firmie, kiedy przychodzi i kto sprawdza postępy. Uzgodnijcie też kontakt w sprawie obecności i trudności.

#### Przykład z małej firmy

Właściciel salonu chce przyjąć jedną osobę. Najpierw sprawdza kwalifikacje instruktorki i czas na naukę. Ze szkołą ustala zadania oraz dni zajęć. Dopiero potem potwierdza miejsce.

> **Zrób teraz**
>
> Zapisz zawód, nazwisko przyszłego instruktora i liczbę miejsc. Przygotuj dokumenty jego kwalifikacji.

Podstawy i pomoc: źródła 1–3.

02

### Koszty i formalności

Wynagrodzenie, ZUS i dwie różne ścieżki wsparcia.

Twój cel

Ustal koszty i formalności.

ETAP 02 / 06

Zatrudnienie ucznia oznacza płacę, składki i czas poświęcony na naukę.

#### Policz pełny koszt

- Wynagrodzenie brutto i składki finansowane przez firmę.

- Czas instruktora oraz obsługa kadr i rozliczeń.

- Badania, szkolenia BHP, odzież, ochrona i materiały do nauki.

Minimum płacy zależy od etapu nauki i przeciętnego wynagrodzenia. Zmienia się w ciągu roku. Poproś kadry o wyliczenie na miesiąc rozpoczęcia pracy.

#### Sprawdź dwie formy wsparcia

Refundacja OHP może pokryć określone wydatki na płace i składki. Potrzebujesz wniosku, spełnienia warunków i umowy. Wydatki ponosisz przed ich rozliczeniem.

Dofinansowanie z gminy dotyczy kosztów kształcenia. To osobny wniosek i decyzja. Właściwa gmina zależy od miejsca zamieszkania młodocianego. Kwotę, termin i warunki sprawdź przed złożeniem wniosku.

#### Przygotuj zatrudnienie

Potrzebne są m.in. pisemna umowa, badania przed pracą, dokumentacja i zgłoszenie do ZUS. Status ucznia nie zwalnia ze składek. Umowa służy nauce zawodu; jej zakończenie nie następuje automatycznie wraz z końcem szkoły.

> **Zrób teraz**
>
> Ustal z kadrami budżet i listę dokumentów. Nie odejmuj od kosztów wsparcia, którego jeszcze nie przyznano.

Podstawy i pomoc: źródła 1, 4 i 5.

03

### Ochrona małoletnich

Sprawdzenie osób i standardy w codziennej pracy.

Twój cel

Przygotuj ochronę małoletnich.

ETAP 03 / 06

Małoletni to osoba, która nie ukończyła 18 lat. Powinna wiedzieć, jak jest chroniona i do kogo może się zwrócić.

„Ustawa Kamilka” to potoczna nazwa zmian wzmacniających ochronę dzieci. W firmie prowadzącej naukę zawodu oznacza to konkretne zasady i działania. Sam podpis ucznia pod dokumentem nie wystarczy.

#### Sprawdź osoby prowadzące naukę

Przed dopuszczeniem do nauczania lub opieki ustal, kto podlega sprawdzeniu. Sprawdź wymagane rejestry i odbierz informację z Krajowego Rejestru Karnego w ustawowym zakresie. Mogą być potrzebne dokumenty zagraniczne. Zachowaj potwierdzenia. Sprawdzenie publicznej listy w internecie nie zastępuje tej procedury.

#### Wprowadź zasady w swojej firmie

Skorzystaj z ministerialnego wzoru dla nauki zawodu i dopasuj go do zakładu. Opisz bezpieczne relacje, zachowania niedozwolone, zgłaszanie problemów i reagowanie. Wyznacz odpowiedzialne osoby. Uwzględnij kontakt online, ochronę wizerunku oraz potrzeby uczniów z niepełnosprawnościami.

#### Szkoła pomoże Ci je przygotować

Nie musisz pisać standardów od zera. ZSZ nr 5 dysponuje odpowiednimi szablonami i chętnie pomoże dopasować je do wielkości firmy, rodzaju pracy i sposobu opieki nad uczniem. Wspólnie ustalicie osoby odpowiedzialne, drogę zgłoszenia problemu i zasady reagowania.

> **Nie ma czego się bać**
>
> W praktyce chodzi przede wszystkim o zdrowy rozsądek: szacunek, zawodowe granice, brak poniżania, jasny kontakt do pomocy i szybką reakcję, gdy dzieje się coś niepokojącego. Wszystko można przygotować krok po kroku razem ze szkołą.

#### Dobre praktyki na co dzień

- Wyznacz osobę do zgłoszeń i zastępstwo na czas jej nieobecności.
- Zapewnij inną drogę zgłoszenia, gdy problem dotyczy instruktora lub właściciela.
- Kontaktuj się z uczniem służbowo i tylko w sprawach związanych z nauką oraz pracą.
- Nie wyśmiewaj, nie strasz i nie traktuj upokorzenia jako metody nauki zawodu.
- Przed pokazaniem czynności wymagającej kontaktu fizycznego wyjaśnij, co robisz i dlaczego.
- Nie publikuj zdjęć ani nagrań ucznia bez sprawdzenia zasad i wymaganych zgód.
- Omów zasady z zespołem i uczniem; sam dokument schowany w segregatorze nie wystarczy.

#### Wyjaśnij je ludziom

Przygotuj zespół. Udostępnij pełne standardy i krótszą wersję zrozumiałą dla uczniów, w lokalu i na stronie internetowej. Oceniaj je co najmniej raz na dwa lata, a wnioski zapisuj. Aktualizuj, gdy potrzeba.

> **Zrób teraz**
>
> Ustal, kto wdraża standardy i sprawdza osoby szkolące. To dwa odrębne zadania.

Podstawy i pomoc: źródła 6–8. To mapa działań, nie gotowy komplet standardów.

04

### Reagowanie

Co robić, gdy uczeń potrzebuje pomocy.

Twój cel

Naucz zespół reagować.

ETAP 04 / 06

Zasady mają działać także wtedy, gdy sytuacja jest nieprzyjemna lub zaskakująca.

#### Ktoś wyśmiewa ucznia

Przerwij zachowanie. Porozmawiaj z uczniem spokojnie, bez publicznego wypytywania. Zastosuj procedurę firmy i przekaż sprawę wyznaczonej osobie. Nie uznawaj poniżania za „naukę odporności”.

#### Uczeń mówi o przemocy

Wysłuchaj go i zadbaj o bezpieczeństwo. Nie obiecuj pełnej tajemnicy. Zapisz fakty i słowa ucznia, bez własnego śledztwa. Uruchom procedurę pomocy oraz właściwe zawiadomienie. Przy podejrzeniu przestępstwa może być potrzebna policja lub prokuratura; w innych sytuacjach także sąd rodzinny.

Jeżeli zagrożone jest życie lub zdrowie, dzwoń pod 112. Nie czekaj na konsultację online. Gdy podejrzenie dotyczy rodzica, nie przekazuj mu automatycznie informacji, które mogą narazić ucznia.

#### Chcesz pokazać ucznia w internecie

Najpierw sprawdź zasady wykorzystania wizerunku i wymagane zgody. Nauka w firmie nie oznacza zgody na zdjęcia reklamowe. Odmowa udziału w promocji nie może pogarszać traktowania ucznia.

#### Uczeń nie wie do kogo pójść

Podaj mu konkretną osobę i zastępstwo. Zapewnij inną drogę zgłoszenia, gdy problem dotyczy instruktora lub właściciela. Uzgodnij kontakt ze szkołą.

> **Zrób teraz**
>
> Przećwicz z zespołem jeden przykład. Każdy powinien wiedzieć, komu i jak zgłasza problem.

Przykłady wdrożeniowe. Dostosuj działania do zdarzenia i procedur; źródła 6–8.

05

### Pierwszy miesiąc

Od przygotowania stanowiska do rozmowy o postępach.

Twój cel

Zaplanuj pierwszy miesiąc.

ETAP 05 / 06

Uczeń powinien od początku wiedzieć, czego się uczy i kto mu pomaga.

#### Przed pierwszym dniem

Sprawdź umowę, badania, kwalifikacje instruktora i wymagane sprawdzenia osób szkolących. Przygotuj bezpieczne stanowisko, dokumenty oraz plan wdrożenia. Przed dopuszczeniem do pracy przeprowadź wymagane szkolenia BHP.

#### Pierwszego dnia

Przedstaw instruktora i zespół. Pokaż miejsce pracy, środki ochrony i drogę zgłoszenia problemu. Wyjaśnij zasady obecności, kontaktu i ochrony małoletnich. Poproś ucznia, aby własnymi słowami powiedział, co zrobi, gdy czegoś nie rozumie.

#### W kolejnych tygodniach

Zaczynaj od prostych zadań. Pokazuj, pozwalaj ćwiczyć pod nadzorem i udzielaj konkretnej informacji zwrotnej. Krótką rozmowę o postępach warto wpisać do planu tygodnia. Ze szkołą sprawdzaj realizację programu.

#### Pamiętaj o czasie i odpoczynku

Obowiązkowa nauka szkolna wlicza się do czasu pracy. Dla młodocianych obowiązują limity zależne od wieku oraz zakaz nadgodzin i pracy nocnej. Urlop planujesz według przepisów, w powiązaniu z feriami. Grafik uzgodnij ze szkołą i kadrami.

> **Zrób teraz**
>
> Przygotuj plan pierwszego tygodnia. Wpisz zadania, osobę prowadzącą i termin krótkiej rozmowy o postępach.

Podstawy i pomoc: źródła 1–3 oraz 6–8.

DWA RODZAJE WSPARCIA

## KOSZTY POD KONTROLĄ. WNIOSKI NA CZAS.

01 / W TRAKCIE ZATRUDNIENIA

### Refundacja OHP

Określone wypłacone wynagrodzenia i opłacone składki. Liczą się warunki programu, umowa i rozliczenia.

02 / NA ZAKOŃCZENIE NAUKI

### Dofinansowanie z gminy

Przy nauce zawodu od 13.07.2025 r. istotne jest przystąpienie do egzaminu, z pozostałymi warunkami. Negatywny wynik sam nie oznacza dawnego limitu 75%.

ETAP 06 / POROZMAWIAJMY

ONLINE · BEZ DOJAZDU

## TWÓJ ZAWÓD. TWOJE PYTANIA. NASZA ROZMOWA.

Sprawdź ze szkołą, jak może wyglądać nauka zawodu w Twojej firmie. Do rozmowy możesz zaprosić przyszłego instruktora lub pracownika kadr.

**ok. 872 zł/mies.**wydatek firmy przed refundacją; 738,65 zł to wynagrodzenie brutto ucznia I roku w okresie 1.09–30.11.2026

**OHP w trakcie**po każdym okresie wskazanym w umowie zwraca rozliczoną pensję i składki do ustalonego limitu — nie dopiero po trzech latach

**10 824 lub 13 394 zł**osobno z gminy po nauce i egzaminie; wyższy limit tylko przy warunku prognozy MEN

kontakt@zsz5.edupage.org

Napisz, aby ustalić termin i sposób połączenia. Konsultacja nie oznacza przyznania refundacji ani potwierdzenia wszystkich warunków zatrudnienia.

DO ROZMOWY

### Wystarczą trzy informacje.

1.  01Jakiego zawodu chcesz uczyć?
2.  02Gdzie działa Twoja firma?
3.  03Ile miejsc rozważasz?

Omówicie możliwości firmy, kwalifikacje instruktora, koszty i ochronę małoletnich. Poproś na koniec o listę dalszych działań.

Na wstępnym spotkaniu opisuj sytuacje bez danych osobowych uczniów.
