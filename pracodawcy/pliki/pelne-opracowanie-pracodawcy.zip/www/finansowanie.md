## Dwa wsparcia, dwa osobne postępowania

Refundacja OHP dotyczy określonych wynagrodzeń i składek. Dofinansowanie z gminy dotyczy kosztów kształcenia. Zaplanuj osobno oba wnioski, terminy i załączniki. Nie odejmuj jeszcze nieprzyznanego wsparcia od budżetu potrzebnego na rozpoczęcie nauki.

| Pytanie | Refundacja OHP | Dofinansowanie z gminy |
| --- | --- | --- |
| Na co? | Określone wypłacone wynagrodzenia i opłacone od nich składki społeczne | Koszty kształcenia |
| Do kogo? | Wojewódzka komenda OHP przez CEiPM właściwe dla miejsca nauki zawodu | Gmina właściwa dla miejsca zamieszkania młodocianego |
| Kiedy działać? | Przy rozpoczęciu zatrudnienia; później rozliczać koszty według umowy | Przygotować dokumenty na zakończenie nauki i egzamin |
| Co jest podstawą? | Wniosek i umowa refundacyjna | Wniosek i decyzja gminy |

## Refundacja OHP

Od **1 grudnia 2025 r.** obowiązuje rozporządzenie z 21 listopada 2025 r. Nie opieraj wniosku wyłącznie na formularzu dołączonym do starszego poradnika.

1. Sprawdź, czy zawód znajduje się we właściwym wojewódzkim wykazie oraz czy osoba szkoląca ma wymagane kwalifikacje.
2. Pobierz bieżący pakiet z OHP i ustal właściwe CEiPM według miejsca nauki zawodu.
3. Przygotuj dokumenty dotyczące zatrudnienia, kwalifikacji i pomocy de minimis. Wniosek obejmuje także deklarację zatrudnienia młodocianego przez co najmniej **6 miesięcy po przygotowaniu zawodowym**. Sprawdź wymagania dotyczące wcześniejszego utrzymania zatrudnienia i swojej sytuacji.
4. Wniosek o zawarcie umowy składaj w roku kalendarzowym zawarcia umowy z młodocianym. Złożenie go później może ograniczyć początek refundacji do roku złożenia wniosku.
5. Po zawarciu umowy składaj rozliczenia wypłat i składek w terminach zapisanych w umowie. Sam pierwszy wniosek nie zastępuje rozliczeń.

Zobowiązanie pracodawcy wobec OHP nie zobowiązuje ucznia do pozostania w firmie. Refundacja ma ustawowe ograniczenia i nie obejmuje automatycznie każdej kwoty płacy ustalonej przez pracodawcę.

[OHP — zasady i aktualny pakiet](https://www.ohp.pl/rozwoj-zawodowy/refundacja/zasady) · [OHP — komunikaty](https://ohp.pl/rozwoj-zawodowy/refundacja/komunikaty) · [MRPiPS — wyjaśnienia](https://psz.praca.gov.pl/dla-pracodawcow-i-przedsiebiorcow/podnoszenie-kompetencji-i-kwalifikacji-pracownikow-i-kandydatow-do-pracy/refundacja-z-fundusz-pracy-wynagrodzen-mlodocianych-pracownikow) · [Rozporządzenie, Dz.U. 2025 poz. 1632](https://eli.gov.pl/eli/DU/2025/1632/ogl)

## Dofinansowanie z gminy

**Przy nauce zawodu od 13 lipca 2025 r. znaczenie ma przystąpienie do właściwego egzaminu, przy ukończeniu nauki i spełnieniu pozostałych warunków.** Nie trzeba ograniczać kwoty do dawnego poziomu 75% tylko dlatego, że wynik egzaminu był negatywny. Przygotuj dokumenty odpowiednie do wyniku i przebiegu nauki.

**100% właściwego limitu nie oznacza zwrotu 100% wydatków firmy.** Przy krótszym okresie kształcenia limit jest proporcjonalny. Gmina sprawdza także kwalifikacje osoby szkolącej, przebieg zatrudnienia i wymagane załączniki. Reguły przystąpienia nie przenoś automatycznie na przyuczenie do określonej pracy — tam ustawa nadal przewiduje zdanie właściwego egzaminu.

| Rodzaj kształcenia | Maksymalny limit ustawowy na 2026 r. |
| --- | --- |
| Nauka zawodu, 36 miesięcy | do **10 824 zł** |
| Nauka zawodu spełniająca warunek prognozy MEN, 36 miesięcy | do **13 394 zł** |
| Przyuczenie do określonej pracy | do **340 zł** za pełny miesiąc |

Kwoty sprawdzono na 25.10.2026. Nie są potwierdzeniem wysokości należnej konkretnej firmie ani prognozą kwot na 2027 r. Waloryzacja zależy od ustawowego progu, kumulacji wskaźników i urzędowego obwieszczenia; nie jest automatycznym podwyższeniem każdego roku. Przed wnioskiem sprawdź aktualne kwoty i właściwy rocznik prognozy.

Wniosek do gminy składa się **w ciągu 3 miesięcy od ogłoszenia wyników egzaminu**. Ustal wcześniej sposób potwierdzenia okresu zatrudnienia i przystąpienia. Gdy egzamin został zdany, potrzebne jest potwierdzenie zdania; przy wyniku negatywnym ustawa przewiduje odpowiednie dokumenty o okresie nauki i przystąpieniu. Skorzystaj z listy załączników swojej gminy.

[Prawo oświatowe — art. 122](https://eli.gov.pl/eli/DU/2026/820/ogl) · [Nowelizacja — art. 23, Dz.U. 2025 poz. 769](https://eli.gov.pl/eli/DU/2025/769/ogl) · [Wrocław — procedura i dokumenty](https://bip.um.wroc.pl/sprawa-do-zalatwienia/8373/dofinansowanie-kosztow-ksztalcenia-mlodocianych-pracownikow) · [Urzędowa informacja na 2026](https://samorzad.gov.pl/web/gmina-stryszow/dofinansowanie-kosztow-ksztalcenia-mlodocianych-pracownikow2)

## Dwie listy zawodów — sprawdź właściwą

**Wykaz refundacyjny województwa** służy do sprawdzenia jednego z warunków refundacji OHP. Poniżej znajdziesz wykaz dolnośląski na 2026 r.

**Prognoza MEN** ma inne zastosowanie, m.in. przy wyższym dofinansowaniu kosztów kształcenia. Sama obecność zawodu na liście refundacyjnej OHP nie oznacza prawa do wyższego limitu gminnego. Sprawdź właściwy zakres prognozy oraz rocznik rozpoczęcia nauki.

[Prognoza MEN 2026 — objaśnienie](https://www.gov.pl/web/edukacja/prognoza-zapotrzebowania-na-pracownikow-w-zawodach-szkolnictwa-branzowego-na-krajowym-i-wojewodzkim-rynku-pracy-2026-juz-opublikowana) · [Pełna prognoza, M.P. 2026 poz. 146](https://api.sejm.gov.pl/eli/acts/MP/2026/146/text.pdf)

## Wykaz refundacyjny — Dolny Śląsk 2026

49 zawodów z załącznika do uchwały nr 4075/VII/26 z 20 kwietnia 2026 r., Dz. Urz. Woj. Dolnośląskiego poz. 2156. Wyszukasz nazwę i sześciocyfrowy kod. Obecność w wykazie jest jednym z warunków — pozostałe sprawdza OHP.

@@ZAWODY@@

[Otwórz urzędowy wykaz PDF](https://edzienniki.duw.pl/DUW/2026/2156/akt.pdf)

## Co warto zrobić teraz?

Zapisz zawód i datę rozpoczęcia nauki. Zapytaj właściwe CEiPM o bieżący pakiet refundacyjny, a gminę o dokumenty wymagane przy zakończeniu nauki. Na konsultację szkolną zabierz pytania o organizację kształcenia; kwestie rozliczeń ustal z kadrami i instytucją udzielającą wsparcia.

[Przygotuj dokumenty](dokumenty.html) · [Zapytaj o konsultację](./#konsultacja)
