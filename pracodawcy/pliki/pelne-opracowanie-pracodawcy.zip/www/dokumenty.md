## Najpierw ustal, do czego służy dokument

Inny zestaw przygotujesz do zatrudnienia, inny do szkoły, a jeszcze inny do OHP lub gminy. Poniższa mapa pomaga uporządkować pracę. Ostateczną listę załączników ustalasz z właściwą instytucją dla swojej sytuacji.

**[Otwórz własną kartę przygotowań](karta-startowa.html)** — możesz wpisać ustalenia i wydrukować kartę. To pomoc organizacyjna, nie formularz urzędowy ani umowa.

## Przed zatrudnieniem i pierwszym dniem

| Przygotuj | Po co i z kim sprawdzić? |
| --- | --- |
| Dokumenty kwalifikacji instruktora | Sprawdź przygotowanie zawodowe i pedagogiczne ze szkołą według obowiązujących przepisów |
| Pisemną umowę o pracę w celu przygotowania zawodowego | Ustal zawód, przebieg przygotowania i warunki zatrudnienia z kadrami; w rzemiośle pomoc może zapewnić cech |
| Badania medycyny pracy i dokumentację BHP | Zadbaj o właściwe orzeczenie przed pracą, szkolenie, ocenę ryzyka i wyposażenie |
| Uzgodnienia programu ze szkołą | Zakres nauki, dni w zakładzie i sposób sprawdzania postępów |
| Grafik uwzględniający obowiązkową naukę szkolną | Szkoła wlicza się do czasu pracy; sprawdź limity wieku, odpoczynek i urlop z kadrami |
| Standardy ochrony małoletnich | Zasady relacji, zgłoszeń i reagowania, wersja dla ucznia oraz osoby odpowiedzialne |
| Potwierdzenia wymaganych sprawdzeń osób szkolących | Odrębna procedura, realizowana przed dopuszczeniem do zadań objętych ustawą |
| Dokumenty zgłoszeniowe i akta pracownicze | Ustal z kadrami zgłoszenie ZUS, dokumentację i terminy zawiadomień |

[PIP — zatrudnianie młodocianych](https://www.pip.gov.pl/dla-pracodawcow/porady-prawne/zatrudnianie-pracownikow-mlodocianych) · [MEN — współpraca szkoły z pracodawcą](https://www.gov.pl/web/nauka/ksztalcenie-mlodocianych-pracownikow) · [Kwalifikacje instruktorów — § 10 rozporządzenia](https://eli.gov.pl/eli/DU/2019/391/ogl)

## W trakcie nauki

Prowadź ewidencję czasu pracy i rozliczenia wynagrodzeń oraz składek. Dokumentuj szkolenia, badania, wydanie wyposażenia i postępy w programie. Uzgodnij ze szkołą, jak korzystać z dzienniczka lub innego dokumentu przebiegu nauki, jak przekazywać oceny i zgłaszać nieobecności.

Zaplanuj krótką rozmowę o postępach po pierwszym miesiącu. Przy zmianie instruktora, pracodawcy lub przebiegu nauki sprawdź, jakie dokumenty i zawiadomienia trzeba zmienić.

## Do OHP i do gminy

**OHP:** aktualny wniosek o umowę refundacyjną, dokumenty zatrudnienia i kwalifikacji, oświadczenia oraz dokumentacja pomocy de minimis. Po podpisaniu umowy — osobne rozliczenia wypłat i składek. Pakiet obejmuje też warunki dotyczące dalszego zatrudnienia.

**Gmina:** aktualny wniosek właściwy dla miejsca zamieszkania młodocianego, dokumenty kwalifikacji i zatrudnienia, dokumentacja pomocy de minimis oraz dokumenty odpowiednie do przebiegu nauki i egzaminu. Pilnuj terminu trzech miesięcy od ogłoszenia wyników.

[Finansowanie — warunki i terminy](finansowanie.html) · [OHP — bieżące zasady i formularze](https://www.ohp.pl/rozwoj-zawodowy/refundacja/zasady) · [Wrocław — dokumenty do dofinansowania](https://bip.um.wroc.pl/sprawa-do-zalatwienia/8373/dofinansowanie-kosztow-ksztalcenia-mlodocianych-pracownikow)

## Ochrona małoletnich — dwa zadania

1. **Sprawdź osoby wykonujące zadania objęte ustawą.** Ustal zakres sprawdzeń, rejestry, informację KRK i ewentualne dokumenty zagraniczne. Zachowaj wymagane potwierdzenia.
2. **Wprowadź i stosuj standardy.** Dopasuj ministerialny wzór dla nauki zawodu do realiów firmy. Wyjaśnij zespołowi i uczniowi bezpieczne relacje, drogę zgłoszenia oraz reakcję na problem. Zapewnij pełną i skróconą wersję standardów, dostępność oraz ocenę co najmniej raz na dwa lata.

[MS — wzory i wytyczne, wybierz naukę zawodu i staże uczniowskie](https://www.gov.pl/web/sprawiedliwosc/standardy-ochrony-maloletnich---wytyczne) · [MS — sprawdzanie osób według art. 21](https://www.gov.pl/web/sprawiedliwosc/jakie-obowiazki-wynikaja-z-art-21-ustawy-o-ochronie-maloletnich) · [Przykłady reakcji w naszym przewodniku](./#reagowanie)

## Poradniki izb — do pogłębienia tematu

**[WIR Poznań — Mistrz szkolący](https://www.irpoznan.com.pl/strona,mistrz-szkolacy-2.html).** Wygodny podział na kwalifikacje, zasady nauki, czas pracy, dokumenty i wsparcie finansowe.

**[Poradnik WIR, wydanie 2023 — PDF](https://www.irpoznan.com.pl/userfiles/files/2023/o%C5%9Bwiata/Poradnik%20mistrza%20szkol%C4%85cego%20.pdf).** Materiał z podanym stanem prawnym na 31.01.2023. Przydatny do poznania roli mistrza; dane finansowe i prawne sprawdzaj według bieżących źródeł.

**[KPIRiP — Przewodnik dla mistrza szkolącego](https://izbarzem.pl/egzaminy-kwalifikacje-zawodowe/przewodnik-dla-mistrza-szkolacego/).** Przykład uporządkowania obowiązków. Zawiera także starsze informacje; nie korzystaj z niego jako samodzielnej instrukcji rozliczeń i zatrudnienia na 2026/2027.

[Zobacz porównanie materiałów i zapis weryfikacji](opracowanie.html#weryfikacja)
