## Umowy i załączniki ZSZ5

Poniżej pobierzesz dokumenty udostępnione w [Strefie Pracodawcy Szkoły Mistrzów](https://szef.szkolamistrzow.info/dokumenty/umowy/). Rozróżniamy pusty formularz i przykład wypełnienia. Przy plikach zachowujemy oznaczenia wersji ze źródła.

- [Umowa o pracę w celu przygotowania zawodowego — formularz](../dokumenty-zsz5/umowa-o-prace-przygotowanie-zawodowe-2023.pdf) — W źródle: 2024/2025 · plik 2023
- [Umowa o pracę — przykład wypełnienia](../dokumenty-zsz5/wzor-umowa-o-prace-2024.pdf) — W źródle: 2025/2026 · plik 2024
- [Załącznik do umowy — ustalenia szkoły i pracodawcy](../dokumenty-zsz5/zalacznik-do-umowy.pdf) — W źródle: 2025/2026
- [Załącznik — mechanik i elektromechanik pojazdów samochodowych](../dokumenty-zsz5/zalacznik-mechanik-elektromechanik.pdf) — W źródle: 2025/2026

Przed podpisaniem uzgodnij ze szkołą dane, terminy i właściwy wariant umowy oraz egzaminu. Przykład wypełnienia zawiera wpisane dane i daty — zastąp je ustaleniami dotyczącymi konkretnego zatrudnienia.

## Jak przygotować komplet?

1. Pobierz **formularz umowy**, a przykład wykorzystaj jako pomoc przy uzupełnianiu.
2. Wybierz **załącznik uzgodnień ze szkołą**. Dla mechanika i elektromechanika pojazdów samochodowych udostępniony jest osobny wariant.
3. Ustal program, dni nauki w firmie, osobę szkolącą oraz sposób przekazywania informacji o postępach.
4. Skompletuj badania, BHP, wymagane sprawdzenia osób szkolących i standardy ochrony małoletnich.

**[Otwórz własną kartę przygotowań](karta-startowa.html)** — możesz wpisać ustalenia i wydrukować kartę. To pomoc organizacyjna, nie formularz urzędowy ani umowa.

## Przed zatrudnieniem i pierwszym dniem

| Przygotuj | Po co i z kim sprawdzić? |
| --- | --- |
| Dokumenty kwalifikacji instruktora | Sprawdź przygotowanie zawodowe i pedagogiczne ze szkołą według obowiązujących przepisów |
| Pisemną umowę o pracę w celu przygotowania zawodowego | Ustal zawód, przebieg przygotowania i warunki zatrudnienia z kadrami; w rzemiośle pomoc może zapewnić cech |
| Badania medycyny pracy i dokumentację BHP | Zadbaj o właściwe orzeczenie przed pracą, szkolenie, ocenę ryzyka i wyposażenie |
| Uzgodnienia programu ze szkołą | Zakres nauki, dni w zakładzie i sposób sprawdzania postępów |
| Grafik uwzględniający obowiązkową naukę szkolną | Szkoła wlicza się do czasu pracy; sprawdź limity wieku, odpoczynek i urlop z kadrami |
| Standardy ochrony małoletnich | Zasady relacji, zgłoszeń i reagowania, wersja dla ucznia oraz osoby odpowiedzialne |
| Potwierdzenia wymaganych sprawdzeń osób szkolących | Odrębna procedura, realizowana przed dopuszczeniem do zadań objętych ustawą |
| Dokumenty zgłoszeniowe i akta pracownicze | Ustal z kadrami zgłoszenie ZUS, dokumentację i terminy zawiadomień |

[PIP — zatrudnianie młodocianych](https://www.pip.gov.pl/dla-pracodawcow/porady-prawne/zatrudnianie-pracownikow-mlodocianych) · [MEN — współpraca szkoły z pracodawcą](https://www.gov.pl/web/nauka/ksztalcenie-mlodocianych-pracownikow) · [Kwalifikacje instruktorów — § 10 rozporządzenia](https://eli.gov.pl/eli/DU/2019/391/ogl)

## W trakcie nauki

Prowadź ewidencję czasu pracy i rozliczenia wynagrodzeń oraz składek. Dokumentuj szkolenia, badania, wydanie wyposażenia i postępy w programie. Uzgodnij ze szkołą, jak korzystać z dzienniczka lub innego dokumentu przebiegu nauki, jak przekazywać oceny i zgłaszać nieobecności.

Zaplanuj krótką rozmowę o postępach po pierwszym miesiącu. Przy zmianie instruktora, pracodawcy lub przebiegu nauki sprawdź, jakie dokumenty i zawiadomienia trzeba zmienić.

## Do OHP i do gminy

**OHP:** aktualny wniosek o umowę refundacyjną, dokumenty zatrudnienia i kwalifikacji, oświadczenia oraz dokumentacja pomocy de minimis. Po podpisaniu umowy — osobne rozliczenia wypłat i składek. Pakiet obejmuje też warunki dotyczące dalszego zatrudnienia.

**Gmina:** aktualny wniosek właściwy dla miejsca zamieszkania młodocianego, dokumenty kwalifikacji i zatrudnienia, dokumentacja pomocy de minimis oraz dokumenty odpowiednie do przebiegu nauki i egzaminu. Pilnuj terminu trzech miesięcy od ogłoszenia wyników.

[Finansowanie — warunki i terminy](finansowanie.html) · [OHP — bieżące zasady i formularze](https://www.ohp.pl/rozwoj-zawodowy/refundacja/zasady) · [Wrocław — dokumenty do dofinansowania](https://bip.um.wroc.pl/sprawa-do-zalatwienia/8373/dofinansowanie-kosztow-ksztalcenia-mlodocianych-pracownikow)

## Ochrona małoletnich — dwa zadania

1. **Sprawdź osoby wykonujące zadania objęte ustawą.** Ustal zakres sprawdzeń, rejestry, informację KRK i ewentualne dokumenty zagraniczne. Zachowaj wymagane potwierdzenia.
2. **Wprowadź i stosuj standardy.** Dopasuj ministerialny wzór dla nauki zawodu do realiów firmy. Wyjaśnij zespołowi i uczniowi bezpieczne relacje, drogę zgłoszenia oraz reakcję na problem. Zapewnij pełną i skróconą wersję standardów, dostępność oraz ocenę co najmniej raz na dwa lata.

[MS — wzory i wytyczne, wybierz naukę zawodu i staże uczniowskie](https://www.gov.pl/web/sprawiedliwosc/standardy-ochrony-maloletnich---wytyczne) · [MS — sprawdzanie osób według art. 21](https://www.gov.pl/web/sprawiedliwosc/jakie-obowiazki-wynikaja-z-art-21-ustawy-o-ochronie-maloletnich) · [Przykłady reakcji w naszym przewodniku](./#reagowanie)

## Programy i dokumentacja nauki

**[Programy i podstawy programowe w Strefie Pracodawcy](https://szef.szkolamistrzow.info/programy-nauczania/).** Znajdziesz tam odsyłacze do ORE, klasyfikacji zawodów i informatorów egzaminacyjnych. Program realizowany w Twojej firmie uzgodnij ze szkołą dla wybranego zawodu i rocznika.

**[Szkolne listy pracodawców według zawodów](https://szef.szkolamistrzow.info/dokumenty/pracodawcy/).** Materiały są podzielone na roczniki 2024/2025 i 2025/2026. Wybierz zawód i sprawdź datę dokumentu.

## Ubezpieczenia i zgłoszenie szkody NNW

Dokumenty pochodzą z [szkolnej sekcji ubezpieczeń](https://szef.szkolamistrzow.info/dokumenty/ubezpieczenia/) i są tam przypisane do roku 2025/2026. Przy zgłoszeniu szkody dobierz dokumenty do faktycznej polisy i okresu ochrony ucznia.

- [OWU — Pakiet Bezpieczna Nauka](../dokumenty-zsz5/owu-pakiet-bezpieczna-nauka.pdf) — W źródle: 2025/2026
- [Wniosek zgłoszenia szkody NNW](../dokumenty-zsz5/wniosek-zgloszenia-szkod-nnw.pdf) — W źródle: 2025/2026
- [Ulotka ubezpieczeniowa ZSZ5](../dokumenty-zsz5/ulotka-zsz5.pdf) — W źródle: 2025/2026
- [Likwidacja szkód TUZ](../dokumenty-zsz5/likwidacja-szkod-tuz.pdf) — W źródle: 2025/2026

## Kontakt w sprawie dokumentów

Jeżeli potrzebujesz właściwego wariantu umowy, aktualnego programu albo pomocy w skompletowaniu dokumentacji, napisz na **[kontakt@zsz5.edupage.org](mailto:kontakt@zsz5.edupage.org)**.

[Zapytaj o konsultację online](./#konsultacja) · [Otwórz Strefę Pracodawcy ZSZ5](https://szef.szkolamistrzow.info/)
