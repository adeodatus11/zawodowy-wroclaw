# Koncepcja działu dla pracodawców

Status: propozycja organizacyjna i redakcyjna, 25.10.2026.

## 1. Cel i odbiorcy

Celem jest doprowadzenie zainteresowanego przedsiębiorcy do świadomej rozmowy ze szkołą oraz przygotowania odpowiedniego miejsca nauki zawodu. Liczba podpisanych umów będzie późniejszym wynikiem pracy organizacyjnej, nie samych odsłon strony.

| Odbiorca | Jego pytanie | Odpowiedź działu |
| --- | --- | --- |
| Właściciel małej firmy, pierwszy raz rozważający szkolenie | Czy dam radę i od czego zacząć? | Krótkie wprowadzenie, lista warunków, kontakt |
| Rzemieślnik lub firma już szkoląca | Co się zmieniło? | Aktualności prawne, dokumenty OHP, rozliczenie kształcenia |
| Kadry i księgowość | Jak zatrudnić, zgłosić i rozliczać? | Instrukcja dokumentów i kosztów z datą aktualizacji |
| Przyszły instruktor | Jakie kwalifikacje i obowiązki? | Ścieżki kwalifikacyjne, program, bezpieczeństwo, współpraca ze szkołą |

## 2. Proponowane otwarcie

**Naucz zawodu. Zbuduj przyszłość swojej firmy.**

„Możesz uczyć młodą osobę zawodu w swojej firmie, współpracując ze szkołą. Zatrudnienie młodocianego oznacza wynagrodzenie, opiekę instruktora i realizację programu nauki. Sprawdź warunki, poznaj koszty i przygotuj się do rozmowy o współpracy.”

Główny przycisk: **Porozmawiaj o współpracy**. Drugi: **Sprawdź przygotowanie firmy**. Publikacja pierwszego wymaga wskazania osoby faktycznie obsługującej zapytania.

## 3. Architektura informacji

Proponowana ścieżka w serwisie: `pracodawcy/`. Najpierw jedna czytelna strona z kotwicami; materiały szczegółowe pod osobnymi adresami. Nazwy poniżej są planem, nie istniejącymi jeszcze podstronami.

| Kolejność | Sekcja | Co użytkownik ma zrozumieć / zrobić | Format |
| --- | --- | --- | --- |
| 1 | Na czym to polega? | Firma zatrudnia i szkoli; szkoła odpowiada za swoją część kształcenia | Krótki tekst i schemat trzech ról |
| 2 | Co zyskuje firma? | Rozwój kadry, przekazanie wiedzy, wpływ na praktyczne umiejętności; efekty wymagają czasu | Trzy konkretne korzyści i realistyczny przykład |
| 3 | Czy moja firma może szkolić? | Instruktor, stanowisko, program, czas, bezpieczeństwo i budżet | Lista pytań bez automatycznego „certyfikatu zgodności” |
| 4 | Jak zacząć? | Rozmowa, weryfikacja warunków, przygotowanie dokumentów, zatrudnienie, wdrożenie | Kroki i lista dokumentów |
| 5 | Ile to kosztuje? | Płaca brutto, narzuty pracodawcy, instruktor i organizacja; pieniądze potrzebne przed zwrotem | Datowana tabela i przykład budżetu |
| 6 | Jakie wsparcie finansowe? | OHP i gmina to dwa postępowania, różne terminy i dokumenty | Porównanie obok siebie |
| 7 | Jak wygląda tydzień i rok nauki? | Szkoła wliczana do czasu pracy, urlopy i harmonogram | Przykład uzgodniony ze szkołą, wyraźnie opisany jako przykład |
| 8 | Bezpieczna nauka zawodu | Badania, BHP, prace wzbronione, nadzór i ochrona małoletnich | Krótka lista przed pierwszym dniem |
| 9 | Egzamin i dalsza współpraca | Właściwy egzamin, dokumenty, decyzja o dalszym zatrudnieniu | Oś czynności przed i po zakończeniu nauki |
| 10 | Pytania i dokumenty | Znalezienie odpowiedzi bez przeglądania całego prawa | FAQ i katalog linków z opisami |
| 11 | Kontakt | Ustalenie następnego kroku | Osoba, rola, e-mail/telefon, godziny kontaktu |

## 4. Trzy poziomy szczegółowości

- **Orientacja, około 3 minut:** na czym polega model, warunki, koszty, pierwszy kontakt.
- **Decyzja, około 15 minut:** przewodnik, lista przygotowań, współpraca ze szkołą, dwie ścieżki finansowania.
- **Realizacja:** wzory i instrukcje kadrowe, źródła przepisów, właściwe formularze instytucji, przypadki szczególne.

Nie umieszczamy wszystkich wyjątków w otwarciu strony. Każdy temat otrzyma jednak wyraźne wejście do szczegółów.

## 5. Pakiet praktyczny do opracowania

1. Jednostronicowa karta „Zatrudnienie młodocianego w skrócie”.
2. Lista „Czy firma jest gotowa?” z miejscem na uwagi i osobę odpowiedzialną.
3. Lista „Przed pierwszym dniem” oraz „Pierwszy miesiąc”.
4. Karta kosztów: wynagrodzenie, narzuty, koszty organizacyjne, termin możliwego zwrotu.
5. Kalendarz obowiązków: początek zatrudnienia, rozliczenia miesięczne, zmiana stawek, egzamin, wniosek do gminy.
6. Karta ustaleń szkoła–pracodawca: zakres programu, dni nauki, monitorowanie, obecności i kontakty.
7. Katalog oficjalnych formularzy: odsyłacze do aktualnych wersji, zamiast kopiowania starych druków.
8. FAQ z krótkimi odpowiedziami i odesłaniem do źródeł.

W pierwszej wersji wystarczą HTML i wygodny wydruk. DOCX/PDF przygotować z tej samej zatwierdzonej treści, gdy będzie potrzebny pakiet na spotkania. Kalkulator netto odłożyć do czasu zatwierdzenia reguł przez kadry; prosty budżet kosztów jest bardziej użyteczny na starcie.

## 6. Promocja działu

Proponowane działania: pakiet dla lokalnych organizacji przedsiębiorców, krótkie spotkanie informacyjne w szkole, rozmowy z firmami w zawodach faktycznie nauczanych oraz historia istniejącej współpracy po uzyskaniu zgody bohaterów. Najpierw dopracować odpowiedzi i obsługę kontaktu, potem kierować ruch do działu.

Tematy czterech materiałów promocyjnych: „Czy mała firma może szkolić?”, „Kto może zostać instruktorem?”, „Co składa się na koszt?”, „Jak szkoła i firma dzielą zadania?”. Każdy kieruje do odpowiedniej części przewodnika. Oznaczenia PIP, ZUS, OHP i izby stosujemy jako wskazanie źródła; nie przedstawiamy tych instytucji jako partnerów projektu bez potwierdzenia.

## 7. Zasady redakcyjne

Najpierw odpowiedź, potem warunki i źródło. Jedno pojęcie na jeden akapit. Rozróżniamy: pracodawca, instruktor, uczeń, młodociany pracownik, szkoła. Terminy „praktykant” i „stażysta” nie zastępują nazwy stosunku prawnego.

Każda kwota ma okres obowiązywania; każdy poradnik datę sprawdzenia. Materiały robocze są wyraźnie oznaczone. Opis pomocy szkoły obejmuje tylko to, co szkoła rzeczywiście zapewnia. Historia sukcesu nie stanowi obietnicy takiego samego rezultatu dla każdej firmy.
