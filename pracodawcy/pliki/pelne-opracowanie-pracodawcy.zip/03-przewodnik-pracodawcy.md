# Zatrudnienie młodocianego — przewodnik dla firmy

Wersja robocza do przygotowania działu internetowego, 25.10.2026. Opis głównej ścieżki: nauka zawodu u pracodawcy we współpracy z branżową szkołą I stopnia. Szczegóły wymagające domknięcia oznaczono wprost. Źródła S01–S23 są opisane i podlinkowane w [rejestrze kwerendy](02-kwerenda-zrodla.md).

## Na czym polega ta współpraca?

Zatrudniasz młodą osobę i uczysz ją zawodu. W firmie zdobywa umiejętności praktyczne pod opieką przygotowanego instruktora. W szkole realizuje odpowiednią część kształcenia. Program, organizację i sposób sprawdzania postępów trzeba połączyć w spójną całość. [MEN — podział zadań](https://www.gov.pl/web/nauka/ksztalcenie-mlodocianych-pracownikow).

Dla firmy to możliwość rozwijania przyszłej kadry i przekazywania własnego doświadczenia. Potrzebne są jednak czas szkolącego, odpowiednie zadania i cierpliwość. Na początku uczeń wymaga pomocy; nie zastępuje samodzielnego fachowca. Ukończenie nauki nie gwarantuje, że pozostanie w firmie.

| Forma | Co ją wyróżnia |
| --- | --- |
| Nauka zawodu przez młodocianego pracownika | Umowa o pracę w celu przygotowania zawodowego; główny temat tego działu |
| Praktyczna nauka zawodu na podstawie umowy szkoły z firmą | Inna podstawa organizacji; nie należy automatycznie przenosić zasad płacy i ZUS z zatrudnienia młodocianego |
| Staż uczniowski | Osobna konstrukcja dla uprawnionych uczniów; wymaga własnego omówienia |
| Prace lekkie | Zatrudnienie w innym celu niż przygotowanie zawodowe; osobne limity i wymogi |
| Przyuczenie do określonej pracy | Inny rodzaj przygotowania zawodowego niż pełna nauka zawodu |

Podstawy rozróżnienia: S03, S04, S06, S15. Samo określenie „kształcenie dualne” nie przesądza rodzaju umowy.

## Kogo można zatrudnić?

Standardowo chodzi o osobę w wieku od 15 lat do ukończenia 18 lat, po ośmioletniej szkole podstawowej, z wymaganym orzeczeniem lekarskim. Przepisy przewidują wyjątki; kandydat młodszy lub bez ukończonej szkoły podstawowej potrzebuje odrębnej weryfikacji. [Kodeks pracy, art. 190–191](https://eli.gov.pl/eli/DU/2026/1245/ogl/pol).

## Czy właściciel musi osobiście szkolić?

Nie zawsze. Szkolenie może prowadzić uprawniona osoba zatrudniona w firmie. Trzeba sprawdzić kwalifikacje zawodowe i przygotowanie pedagogiczne osoby, która faktycznie będzie instruktorem. Sam staż pracy albo sam kurs pedagogiczny nie potwierdza spełnienia całego zestawu wymagań. Istnieją różne ścieżki kwalifikacyjne, dlatego warto zebrać dyplomy, świadectwa i dokumenty doświadczenia, a następnie zestawić je z § 10 rozporządzenia. [Praktyczna nauka zawodu](https://eli.gov.pl/api/acts/DU/2019/391/text.html).

Lokalnym punktem orientacyjnym jest [oferta kursu pedagogicznego Dolnośląskiej Izby Rzemieślniczej](https://izba.wroc.pl/kurs-pedagogiczny/). Dostępność kursu i spełnienie wymagań wstępnych wymagają sprawdzenia.

## Jak zacząć — siedem kroków

1. **Określ zawód i możliwości firmy.** Jakich czynności można się u Ciebie nauczyć, kto będzie szkolił i ile czasu przeznaczy na opiekę?
2. **Omów współpracę ze szkołą.** Ustal zgodność z programem, podział zajęć, harmonogram, ocenianie i kontakt w razie problemów.
3. **Sprawdź instruktora i miejsce nauki.** Przygotuj dokumenty kwalifikacji oraz ocenę bezpieczeństwa stanowiska.
4. **Policz budżet.** Uwzględnij płacę, składki, opiekę, wyposażenie i oczekiwanie na ewentualny zwrot kosztów.
5. **Przygotuj zatrudnienie.** Umowa, dokumentacja kadrowa, badania, obowiązkowe zawiadomienia i uzgodnienia ze szkołą.
6. **Przeprowadź wdrożenie.** BHP, zasady bezpieczeństwa, przedstawienie instruktora, plan pierwszych zadań i sposób zgłaszania nieobecności.
7. **Prowadź i dokumentuj naukę.** Monitoruj postępy, obecności i koszty, a odpowiednio wcześniej przygotuj egzamin i wnioski finansowe.

To proponowana kolejność organizacyjna. Szczegółowa lista dokumentów musi uwzględniać sytuację firmy i ucznia.

## Jakiej umowy potrzebuję?

Umowa o pracę w celu przygotowania zawodowego powinna określać m.in. rodzaj przygotowania, jego czas i miejsce, sposób nauki teorii oraz wynagrodzenie. Co do zasady stosuje się zasady umów na czas nieokreślony. Określenie czasu nauki nie oznacza samo w sobie daty rozwiązania stosunku pracy. Umowę zawiera pracodawca z młodocianym; szczególne przypadki wieku wymagają sprawdzenia dodatkowych warunków. Nie należy wpisywać zobowiązania ucznia do „odpracowania” nauki ani zwrotu jej kosztów za odejście. [PIP — umowa z młodocianym](https://www.pip.gov.pl/dla-pracodawcow/porady-prawne/zatrudnianie-pracownikow-mlodocianych).

Do pakietu wdrożeniowego przewidziano kartę uzgodnień ze szkołą: program, dni praktyki i monitorowanie. Nie zastępuje ona umowy o pracę.

## Ile wynosi wynagrodzenie?

Minimalne wynagrodzenie w nauce zawodu jest powiązane z przeciętnym wynagrodzeniem kwartalnym, a nie ze zwykłą płacą minimalną. Minimalne udziały wynoszą 8%, 9% i 10%; dla przyuczenia 7%. [Rozporządzenie zmieniające stawki](https://eli.gov.pl/api/acts/DU/2023/1348/text.html).

Przykład na okres **1.09–30.11.2026**, obliczony z podstawy **9233,13 zł** wskazanej w [komunikacie GUS za II kwartał 2026](https://stat.gov.pl/sygnalne/komunikaty-i-obwieszczenia/lista-komunikatow-i-obwieszczen/komunikat-w-sprawie-przecietnego-wynagrodzenia-w-drugim-kwartale-2026-r-%2C271%2C53.html):

| Etap | Minimum | Miesięcznie brutto |
| --- | --- | --- |
| I rok nauki / odpowiednia klasa | 8% | 738,65 zł |
| II rok nauki / odpowiednia klasa | 9% | 830,98 zł |
| III rok nauki / odpowiednia klasa | 10% | 923,31 zł |
| Przyuczenie do określonej pracy | 7% | 646,32 zł |

To kwoty za pełny miesiąc w standardowej sytuacji, przed potrąceniami i bez narzutów pracodawcy. Wyższa płaca jest możliwa. Nie stosować tabeli automatycznie do niepełnego miesiąca, choroby ani późniejszego okresu. Mechanizm daty aktualizacji wynika z § 19 rozporządzenia bazowego S04.

**Budżet firmy** powinien obejmować także składki finansowane przez pracodawcę, czas instruktora, badania i BHP, odzież oraz ochronę, materiały, narzędzia, obsługę kadrową i koszty właściwej ścieżki egzaminacyjnej. Proponowany arkusz kosztów ma oddzielać wydatki pewne od spodziewanej refundacji.

## Co z ZUS?

Młodociany zatrudniony na umowę o pracę podlega ubezpieczeniom społecznym, w tym chorobowemu, oraz zdrowotnemu. Zgłoszenie na ZUS ZUA następuje w ciągu 7 dni od powstania obowiązku ubezpieczenia. Potrzebne są także bieżące rozliczenia. [ZUS — obowiązki przy zatrudnieniu pracownika](https://www.zus.pl/documents/10182/167561/Jestes_pracownikiem.pdf/).

Dokładną kwotę netto i narzuty powinna wyliczyć obsługa kadrowa. Przed przygotowaniem kalkulatora trzeba potwierdzić kody, zasady składki zdrowotnej i funduszy oraz obsługę nieobecności i ukończenia 18 lat. Sama informacja „uczeń” nie wystarcza do rozliczenia.

## Czy mogę uzyskać wsparcie finansowe?

| | Refundacja OHP | Dofinansowanie kształcenia |
| --- | --- | --- |
| Przedmiot | Określone wydatki na płace i składki społeczne | Koszty kształcenia rozliczane w związku z zakończeniem nauki |
| Instytucja | Wojewódzka komenda OHP przez właściwe CEiPM | Właściwa gmina według zamieszkania młodocianego |
| Podstawa | Wniosek, warunki programu i umowa refundacyjna | Wniosek i decyzja administracyjna |
| Co sprawdzić | Zawód, instruktor, dokumenty, terminy, zobowiązania i dostępne środki | Okres nauki, egzamin, kwalifikacje, termin i załączniki |
| Ryzyko dla budżetu | Wydatki ponosisz przed rozliczeniem; nie ma automatycznej refundacji całej płacy | Nie traktuj przyszłej decyzji jako pieniędzy dostępnych w pierwszym miesiącu |

Podstawy: [nowe rozporządzenie OHP](https://eli.gov.pl/eli/DU/2025/1632/ogl), [Prawo oświatowe](https://eli.gov.pl/eli/DU/2026/820/ogl), [procedura Wrocławia](https://bip.um.wroc.pl/sprawa-do-zalatwienia/8373/dofinansowanie-kosztow-ksztalcenia-mlodocianych-pracownikow).

Wniosek o umowę refundacyjną należy przygotować w roku zawarcia umowy z młodocianym. Późniejsze złożenie może ograniczyć okres objęty refundacją. Wniosek o dofinansowanie gminne jest związany z terminem 3 miesięcy od ogłoszenia wyników egzaminu. Nie są to te same wnioski.

W art. 122 odczytano kwoty bazowe do 10 824 zł lub do 13 394 zł przy 36 miesiącach nauki oraz do 340 zł za pełny miesiąc przyuczenia. Wyższy limit wymaga spełnienia warunku dotyczącego zawodu. **Przed publikacją tabeli dotacji trzeba potwierdzić waloryzację, datę stosowania i sposób rozliczenia niezdania egzaminu.** Rejestr opisuje różnicę między historycznym 75/25 a brzmieniem 100% w tekście z 2026 r. Te kwoty nie są obietnicą wypłaty dla konkretnej firmy.

## Jak organizować czas pracy i urlopy?

Do 16 lat limit wynosi 6 godzin na dobę, powyżej 16 lat — 8. Wlicza się obowiązkowe zajęcia szkolne. Nie wolno planować nadgodzin ani pracy nocnej. Przerwa 30 minut należy się przy wymiarze ponad 4,5 godziny. Odpoczynek: co najmniej 14 godzin dobowo i 48 tygodniowo, z niedzielą. Pora nocna standardowo obejmuje 22:00–6:00; dla ustawowych wyjątków 20:00–6:00.

Pierwszy urlop: 12 dni po 6 miesiącach, następnie 26 dni po roku pracy. Rok ukończenia 18 lat ma szczególną regułę. Urlop ucznia planuje się w ferie szkolne; całe wakacje nie stają się automatycznie wolne od pracy. Podstawa: [Kodeks pracy, art. 202–205](https://eli.gov.pl/eli/DU/2026/1245/ogl/pol).

Szkoła i kadry powinny wspólnie sprawdzić przykładowy grafik przed jego użyciem. Podane zasady dotyczą głównej ścieżki nauki zawodu, nie tabeli limitów dla prac lekkich.

## Bezpieczne miejsce nauki

Przed dopuszczeniem ucznia trzeba przygotować badania, szkolenie BHP, ocenę ryzyka, wymagane środki ochrony oraz zasady nadzoru. Sprawdzenie prac wzbronionych dotyczy rzeczywistych czynności. To, że czynność występuje w programie zawodu, nie wystarcza do jej powierzenia bez spełnienia warunków. [Przepisy o pracach wzbronionych](https://eli.gov.pl/api/acts/DU/2023/1240/text.html).

Firma prowadząca kształcenie ma również przygotować standardy ochrony małoletnich dostosowane do zakładu. Osobno trzeba ustalić obowiązki sprawdzenia osób szkolących i opiekujących się uczniami. [Wyjaśnienia MEN przedstawione przez RPD](https://brpd.gov.pl/2024/08/09/bez-zmian-w-organizacji-praktyk-zawodowych/), [procedura sprawdzania — Ministerstwo Sprawiedliwości](https://www.gov.pl/web/sprawiedliwosc/jakie-obowiazki-wynikaja-z-art-21-ustawy-o-ochronie-maloletnich).

## Co zrobić, gdy pojawia się problem?

Proponujemy prostą ścieżkę organizacyjną: zapisz problem, porozmawiaj z uczniem, skontaktuj się z wyznaczoną osobą w szkole i ustal dalsze działania. Zagrożenie bezpieczeństwa wymaga natychmiastowego reagowania. Rozwiązanie umowy, choroba, ciąża albo zmiana miejsca szkolenia wymagają osobnej oceny kadrowej; nie wystarczy wykreślić ucznia z grafiku.

Wypowiedzenie przez pracodawcę podlega szczególnym ograniczeniom. Sam spadek zapotrzebowania na pomoc ucznia nie oznacza dowolności zakończenia umowy. [PIP — rozwiązywanie umów](https://www.pip.gov.pl/dla-pracodawcow/porady-prawne/zatrudnianie-pracownikow-mlodocianych).

## Lista przygotowań do pierwszej rozmowy

- [ ] Zawód, zakres czynności i miejsce szkolenia.
- [ ] Proponowany instruktor i jego dokumenty kwalifikacji.
- [ ] Liczba miejsc i realny czas dostępny na szkolenie.
- [ ] Wstępny budżet obejmujący również okres oczekiwania na refundację.
- [ ] Warunki lokalowe, wyposażenie i kwestie BHP do sprawdzenia.
- [ ] Pytania o harmonogram szkoły, program i ocenianie.
- [ ] Osoba w firmie odpowiedzialna za kadry i kontakt ze szkołą.

Lista służy przygotowaniu rozmowy. Nie zastępuje sprawdzenia warunków zatrudnienia.
