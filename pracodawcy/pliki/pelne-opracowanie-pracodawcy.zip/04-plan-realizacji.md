# Szczegółowy plan uruchomienia działu

Propozycja z 25.10.2026. Plan obejmuje treść, obsługę zainteresowanych firm, materiały praktyczne i wdrożenie w istniejącym serwisie. Daty są względne: dzień 1 oznacza rozpoczęcie prac wdrożeniowych po wyznaczeniu koordynatora. Nie wiążemy ich automatycznie z kalendarzem konkursu.

## 1. Stan wykonania

Wykonano przegląd repozytorium, kwerendę źródeł, ocenę rozbieżności i przewodnik. Opublikowano serwis „Ucz zawodu” z publikacją PDF/Word i kontaktem do konsultacji. Uzupełnienie na podstawie materiałów organizatora obejmuje finansowanie, katalog dokumentów, kartę przygotowań oraz przykłady szkół. Rozstrzygnięto zmianę art. 122 i odczytano dolnośląski wykaz refundacyjny 2026. Bieżący zapis weryfikacji znajduje się w dokumencie 05; poniższy harmonogram jest pierwotną propozycją organizacyjną. Nie uruchomiono automatycznego formularza zgłoszeń ani systemu rezerwacji.

## 2. Kolejność i odpowiedzialność

Podane role są propozycją, nie przydziałem obowiązków konkretnym osobom.

| Etap | Kiedy | Działania | Produkt i warunek ukończenia | Proponowana rola |
| --- | --- | --- | --- | --- |
| 1. Oferta szkoły | Dni 1–2 | Potwierdzić zawody, model kształcenia, liczbę miejsc, rekrutację i zakres pomocy | Jednostronicowa karta oferty bez niepotwierdzonych deklaracji | Koordynator + kierownik szkolenia praktycznego |
| 2. Domknięcie kwerendy | Dni 2–4 | Sprawdzić lokalne OHP, art. 122 i waloryzację, ZUS/KAS, egzamin, kwalifikacje i małoletnich | Rejestr źródeł z rozstrzygnięciem każdego pytania finansowego i prawnego używanego publicznie | Redaktor + kadry/księgowość + osoba ds. BHP; konsultacje instytucjonalne według potrzeb |
| 3. Treść główna | Dni 4–6 | Przeredagować przewodnik na stronę i krótkie FAQ, dopisać pomoc szkoły | Tekst odpowiadający na całą ścieżkę od decyzji do egzaminu, z linkami | Redaktor + koordynator |
| 4. Pakiet do działania | Dni 6–8 | Karty gotowości, dokumentów, kosztów, kalendarza i ustaleń | Jeden komplet oparty na tym samym źródle treści; przykłady opisane jako przykłady | Redaktor + kadry + szkoła |
| 5. Wdrożenie WWW | Dni 8–10 | Dodać dział i nawigację w istniejącym `site/`, style i wydruk | Czytelna wersja mobilna i desktopowa, działające odsyłacze, kontakt | Osoba utrzymująca stronę |
| 6. Próba z firmami | Dni 11–12 | Krótkie zadania z 3–5 przedstawicielami firm, poprawki | Użytkownicy odnajdują warunki, koszty, różnicę finansowania i kontakt | Koordynator + redaktor |
| 7. Uruchomienie | Dni 13–15 | Końcowa kontrola dat i kontaktu, publikacja, przygotowanie spotkania | Dział dostępny i osoba gotowa odpowiadać; materiały promocyjne zgodne ze stroną | Koordynator + administrator |

Orientacyjny nakład: **40–60 godzin pracy zespołu**, plus czas oczekiwania na odpowiedzi instytucji i ustalenia organizacyjne. To estymacja, nie zatwierdzony budżet. Jeśli konsultacje się wydłużą, można ukończyć redakcję części ogólnej i techniczny szkic, utrzymując sporne szczegóły finansowe w wersji roboczej.

## 3. Konkretny zakres dalszego sprawdzenia

| Temat | Pytanie do rozstrzygnięcia | Dowód zakończenia |
| --- | --- | --- |
| OHP | Właściwa jednostka, aktualny dolnośląski wykaz zawodów i formularze; warunki dalszego zatrudnienia i rozliczeń | Aktualne adresy dokumentów, data, zaznaczone właściwe przepisy i warunki umowy |
| Gmina / art. 122 | Zastosowanie aktualnych zasad do konkretnego rocznika i daty wniosku; niezdany egzamin; waloryzacja | Porównanie aktów i formularza; w razie utrzymania niejasności odpowiedź właściwego urzędu |
| ZUS i PIT | Kod zgłoszenia, składki, fundusze, podatek, pełnoletność, nieobecności | Sprawdzony przez kadry przykład pełnego i niepełnego miesiąca, z założeniami |
| Instruktor | Które ścieżki kwalifikacji są adekwatne do zawodów szkoły? | Tabela wymaganych dokumentów i reguła indywidualnej oceny |
| BHP | Jakie czynności i stanowiska wystąpią u pracodawców? | Lista zagadnień branżowych do sprawdzenia; bez fikcyjnej uniwersalnej zgody na maszyny |
| Ochrona małoletnich | Standardy i sprawdzenie osób prowadzących naukę | Instrukcja dostosowania wzoru i odpowiedzialności, z aktualnymi podstawami |
| Egzaminy | Kto organizuje, jakie terminy i dokumenty, kto ponosi opłaty? | Osobna ścieżka rzemieślnicza i pozarzemieślnicza, zatwierdzona ze szkołą |
| Oferta lokalna | Z kim kontaktuje się firma i co otrzymuje po pierwszej rozmowie? | Imię/rola lub skrzynka funkcyjna, potwierdzony zakres pomocy i czas odpowiedzi |

## 4. Obsługa zainteresowanej firmy

Propozycja procesu: kontakt → krótka rozmowa o zawodzie i możliwościach → weryfikacja instruktora i warunków → ustalenia programu → dokumenty → start nauki → przegląd po pierwszym miesiącu.

Na pierwszym etapie wystarczy e-mail lub telefon. Formularz można dodać po ustaleniu administratora danych i obsługi. W zgłoszeniu zainteresowania potrzebne są zasadniczo: firma, zawód, miejscowość i kontakt. Dokumenty ucznia, PESEL, badania i informacje o karalności nie powinny trafiać do publicznego repozytorium ani prostego formularza promocyjnego.

Proponowany standard organizacyjny: potwierdzenie kontaktu do 2 dni roboczych i wskazanie kolejnego kroku. Publikować go dopiero po potwierdzeniu możliwości szkoły. W rejestrze kontaktów zapisywać wynik rozmowy i dalszą czynność; nie opisywać zainteresowanej firmy jako partnera przed uzgodnieniem współpracy.

## 5. Plan FAQ

Pierwsza wersja powinna odpowiedzieć na pytania:

1. Czy jednoosobowa firma może szkolić ucznia?
2. Czy muszę mieć tytuł mistrza? Czy wystarczy kurs pedagogiczny?
3. Czy właściciel musi być instruktorem?
4. Kto podpisuje umowę i jaka jest rola rodzica?
5. Czy umowa kończy się razem ze szkołą?
6. Ile dni uczeń jest w firmie i jak liczyć szkołę do czasu pracy?
7. Czy pracuje w wakacje, soboty i wieczorem?
8. Ile wynosi płaca i co jeszcze kosztuje firmę?
9. Czy uczeń podlega ZUS? Kiedy trzeba go zgłosić?
10. Czym różni się refundacja OHP od dofinansowania gminnego?
11. Czy firma może otrzymać oba instrumenty i jakie warunki trzeba sprawdzić?
12. Co jeśli pracownik nie zda egzaminu lub zmieni pracodawcę?
13. Co zmienia ukończenie 18 lat?
14. Jak zgłaszać nieobecności i rozwiązywać problemy?
15. Co zapewnia szkoła i z kim rozmawiać?

Odpowiedź: 2–5 zdań, istotny warunek, odsyłacz do szczegółu i źródła. Brak rozstrzygnięcia nie może być maskowany kategorycznym „tak” albo „nie”.

## 6. Kryteria gotowości do publikacji

- [ ] Każda kwota ma okres obowiązywania oraz podstawę obliczenia.
- [ ] Nie ma historycznych stawek ani automatycznej obietnicy refundacji.
- [ ] Rozstrzygnięto publicznie używane szczegóły art. 122 i warunki OHP.
- [ ] Praktyki szkolne, staż i pracownik młodociany nie są wymieszane.
- [ ] Osoba szkoląca, czas pracy, BHP i ochrona małoletnich mają kompletne objaśnienie.
- [ ] Kontakt, zawody i zakres wsparcia szkoły zostały faktycznie potwierdzone.
- [ ] Każdy plik i oficjalny formularz otwiera się; stare druki usunięto z rekomendacji.
- [ ] Strona działa na telefonie, z klawiatury i po powiększeniu; tabele oraz wydruk są czytelne.
- [ ] Przykładowy pracodawca umie wskazać następny krok po przeczytaniu strony.

Kontrola to propozycja procesu zapewnienia jakości wynikająca z charakteru publikacji, nie dodatkowy wymóg uzyskania zgody użytkownika na bieżącą kwerendę.

## 7. Test z użytkownikami i wskaźniki

Zaprosić 3–5 osób reprezentujących małe firmy, w tym przynajmniej jedną bez doświadczenia w szkoleniu. Zadania: znajdź warunki dla instruktora, ustal co oprócz płacy kosztuje firmę, wskaż dwie instytucje finansujące i znajdź pierwszy kontakt. Zapisać miejsca, w których uczestnicy szukają pomocy. Kryterium robocze: co najmniej 4 z 5 osób wykonuje kluczowe zadania bez wyjaśnień prowadzącego; przy mniejszej próbie podawać liczby, nie pozornie dokładne procenty.

Mierzyć: unikalne firmy pytające o współpracę, odbyte rozmowy, zweryfikowane miejsca nauki, zawarte umowy, rozpoczęte szkolenia i kontynuację po 3 miesiącach. Oddzielać zainteresowanie od rzeczywistego startu. Nie trzeba od razu instalować analityki strony — na pilotaż wystarczy rejestr obsługi kontaktów i krótka dobrowolna ocena przydatności materiału.

## 8. Aktualizacja po uruchomieniu

| Element | Częstotliwość / zdarzenie | Proponowany właściciel |
| --- | --- | --- |
| Wynagrodzenia | Przed 1 marca, 1 czerwca, 1 września i 1 grudnia; sprawdzić właściwy komunikat GUS | Kadry + redaktor |
| OHP | Przed naborem oraz po nowym komunikacie lub zmianie formularzy | Koordynator |
| Dofinansowanie gminne | Przed sezonem egzaminacyjnym, po waloryzacji i zmianie prawa | Koordynator + kadry |
| Kontakt i oferta szkoły | Na początku semestru i przy każdej zmianie organizacyjnej | Szkoła |
| Przepisy i FAQ | Co kwartał oraz po zmianie dotyczącej opublikowanej treści | Redaktor merytoryczny |
| Linki i pliki | Co miesiąc | Administrator strony |

Przegląd musi pozostawić datę i krótki zapis zmian. Po wygaśnięciu okresu tabeli wynagrodzeń wyświetlić jej okres historyczny; nie pozostawiać etykiety „aktualne”. Właściciel treści powinien móc poprawić jeden dokument źródłowy i odtworzyć z niego stronę oraz wydruk.
