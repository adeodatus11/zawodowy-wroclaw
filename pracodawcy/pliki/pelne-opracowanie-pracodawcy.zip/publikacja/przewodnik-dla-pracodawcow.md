# Zatrudnij młodocianego i ucz zawodu

Jak przygotować firmę, zadbać o bezpieczeństwo i zacząć współpracę ze szkołą.

Kształcenie dualne łączy naukę w szkole z nauką w firmie. Ten przewodnik opisuje zatrudnienie młodocianego na umowę o pracę w celu przygotowania zawodowego. Praktyki szkolne i staż uczniowski mają inne zasady.

## Co może zyskać Twoja firma

- Rozwijasz przyszłą kadrę. Uczeń poznaje zawód i sposób pracy Twojego zespołu.

- Przekazujesz doświadczenie. Umiejętności fachowców trafiają do kolejnego pokolenia.

- Budujesz relację ze szkołą. Możecie wspólnie planować zadania i sprawdzać postępy.

To inwestycja w ludzi. Wymaga czasu instruktora, budżetu i cierpliwości. Uczeń stopniowo zyskuje samodzielność; dalsze zatrudnienie zależy od obu stron.

## Przejdź przez sześć kroków

1  Sprawdź możliwości firmy
2  Ustal koszty i formalności
3  Przygotuj ochronę małoletnich
4  Naucz zespół reagować
5  Zaplanuj pierwszy miesiąc
6  Porozmawiaj ze szkołą online

Zawodowy Wrocław • Szkoła Mistrzów
Opracowanie informacyjne • 25 października 2026

---

# Sprawdź możliwości firmy

Zacznij od zawodu, osoby szkolącej i miejsca do nauki.

## Wybierz osobę szkolącą

Instruktor praktycznej nauki zawodu uczy ucznia codziennych zadań. Potrzebuje odpowiednich kwalifikacji zawodowych i przygotowania pedagogicznego. Możesz szkolić osobiście albo wyznaczyć uprawnionego pracownika. Samo doświadczenie w branży nie wystarczy.

## Sprawdź stanowisko

Uczeń potrzebuje bezpiecznych narzędzi i zadań zgodnych z programem. Nie każdą czynność dorosłego pracownika można powierzyć młodocianemu. Ograniczenia sprawdź z osobą zajmującą się BHP i lekarzem medycyny pracy.

## Ustal podział ze szkołą

Omówcie, czego uczeń nauczy się w firmie, kiedy przychodzi i kto sprawdza postępy. Uzgodnijcie też kontakt w sprawie obecności i trudności.

## Przykład z małej firmy

Właściciel salonu chce przyjąć jedną osobę. Najpierw sprawdza kwalifikacje instruktorki i czas na naukę. Ze szkołą ustala zadania oraz dni zajęć. Dopiero potem potwierdza miejsce.

Twój następny krok  Zapisz zawód, nazwisko przyszłego instruktora i liczbę miejsc. Przygotuj dokumenty jego kwalifikacji.

Podstawy i pomoc: źródła 1–3 na ostatniej stronie.

---

# Ustal koszty i formalności

Zatrudnienie ucznia oznacza płacę, składki i czas poświęcony na naukę.

## Policz pełny koszt

- Wynagrodzenie brutto i składki finansowane przez firmę.

- Czas instruktora oraz obsługa kadr i rozliczeń.

- Badania, szkolenia BHP, odzież, ochrona i materiały do nauki.

Minimum płacy zależy od etapu nauki i przeciętnego wynagrodzenia. Zmienia się w ciągu roku. Poproś kadry o wyliczenie na miesiąc rozpoczęcia pracy.

## Sprawdź dwie formy wsparcia

Refundacja OHP może pokryć określone wydatki na płace i składki. Potrzebujesz wniosku, spełnienia warunków i umowy. Wydatki ponosisz przed ich rozliczeniem.

Dofinansowanie z gminy dotyczy kosztów kształcenia. To osobny wniosek i decyzja. Właściwa gmina zależy od miejsca zamieszkania młodocianego. Kwotę, termin i warunki sprawdź przed złożeniem wniosku.

## Przygotuj zatrudnienie

Potrzebne są m.in. pisemna umowa, badania przed pracą, dokumentacja i zgłoszenie do ZUS. Status ucznia nie zwalnia ze składek. Umowa służy nauce zawodu; jej zakończenie nie następuje automatycznie wraz z końcem szkoły.

Twój następny krok  Ustal z kadrami budżet i listę dokumentów. Nie odejmuj od kosztów wsparcia, którego jeszcze nie przyznano.

Podstawy i pomoc: źródła 1, 4 i 5.

---

# Przygotuj ochronę małoletnich

Małoletni to osoba, która nie ukończyła 18 lat. Powinna wiedzieć, jak jest chroniona i do kogo może się zwrócić.

„Ustawa Kamilka” to potoczna nazwa zmian wzmacniających ochronę dzieci. W firmie prowadzącej naukę zawodu oznacza to konkretne zasady i działania. Sam podpis ucznia pod dokumentem nie wystarczy.

## Sprawdź osoby prowadzące naukę

Przed dopuszczeniem do nauczania lub opieki ustal, kto podlega sprawdzeniu. Sprawdź wymagane rejestry i odbierz informację z Krajowego Rejestru Karnego w ustawowym zakresie. Mogą być potrzebne dokumenty zagraniczne. Zachowaj potwierdzenia. Sprawdzenie publicznej listy w internecie nie zastępuje tej procedury.

## Wprowadź zasady w swojej firmie

Skorzystaj z ministerialnego wzoru dla nauki zawodu i dopasuj go do zakładu. Opisz bezpieczne relacje, zachowania niedozwolone, zgłaszanie problemów i reagowanie. Wyznacz odpowiedzialne osoby. Uwzględnij kontakt online, ochronę wizerunku oraz potrzeby uczniów z niepełnosprawnościami.

## Wyjaśnij je ludziom

Przygotuj zespół. Udostępnij pełne standardy i krótszą wersję zrozumiałą dla uczniów, w lokalu i na stronie internetowej. Oceniaj je co najmniej raz na dwa lata, a wnioski zapisuj. Aktualizuj, gdy potrzeba.

Twój następny krok  Ustal, kto wdraża standardy i sprawdza osoby szkolące. To dwa odrębne zadania.

Podstawy i pomoc: źródła 6–8. To mapa działań, nie gotowy komplet standardów.

---

# Naucz zespół reagować

Zasady mają działać także wtedy, gdy sytuacja jest nieprzyjemna lub zaskakująca.

## Ktoś wyśmiewa ucznia

Przerwij zachowanie. Porozmawiaj z uczniem spokojnie, bez publicznego wypytywania. Zastosuj procedurę firmy i przekaż sprawę wyznaczonej osobie. Nie uznawaj poniżania za „naukę odporności”.

## Uczeń mówi o przemocy

Wysłuchaj go i zadbaj o bezpieczeństwo. Nie obiecuj pełnej tajemnicy. Zapisz fakty i słowa ucznia, bez własnego śledztwa. Uruchom procedurę pomocy oraz właściwe zawiadomienie. Przy podejrzeniu przestępstwa może być potrzebna policja lub prokuratura; w innych sytuacjach także sąd rodzinny.

Jeżeli zagrożone jest życie lub zdrowie, dzwoń pod 112. Nie czekaj na konsultację online. Gdy podejrzenie dotyczy rodzica, nie przekazuj mu automatycznie informacji, które mogą narazić ucznia.

## Chcesz pokazać ucznia w internecie

Najpierw sprawdź zasady wykorzystania wizerunku i wymagane zgody. Nauka w firmie nie oznacza zgody na zdjęcia reklamowe. Odmowa udziału w promocji nie może pogarszać traktowania ucznia.

## Uczeń nie wie do kogo pójść

Podaj mu konkretną osobę i zastępstwo. Zapewnij inną drogę zgłoszenia, gdy problem dotyczy instruktora lub właściciela. Uzgodnij kontakt ze szkołą.

Twój następny krok  Przećwicz z zespołem jeden przykład. Każdy powinien wiedzieć, komu i jak zgłasza problem.

Przykłady wdrożeniowe. Dostosuj działania do zdarzenia i procedur; źródła 6–8.

---

# Zaplanuj pierwszy miesiąc

Uczeń powinien od początku wiedzieć, czego się uczy i kto mu pomaga.

## Przed pierwszym dniem

Sprawdź umowę, badania, kwalifikacje instruktora i wymagane sprawdzenia osób szkolących. Przygotuj bezpieczne stanowisko, dokumenty oraz plan wdrożenia. Przed dopuszczeniem do pracy przeprowadź wymagane szkolenia BHP.

## Pierwszego dnia

Przedstaw instruktora i zespół. Pokaż miejsce pracy, środki ochrony i drogę zgłoszenia problemu. Wyjaśnij zasady obecności, kontaktu i ochrony małoletnich. Poproś ucznia, aby własnymi słowami powiedział, co zrobi, gdy czegoś nie rozumie.

## W kolejnych tygodniach

Zaczynaj od prostych zadań. Pokazuj, pozwalaj ćwiczyć pod nadzorem i udzielaj konkretnej informacji zwrotnej. Krótką rozmowę o postępach warto wpisać do planu tygodnia. Ze szkołą sprawdzaj realizację programu.

## Pamiętaj o czasie i odpoczynku

Obowiązkowa nauka szkolna wlicza się do czasu pracy. Dla młodocianych obowiązują limity zależne od wieku oraz zakaz nadgodzin i pracy nocnej. Urlop planujesz według przepisów, w powiązaniu z feriami. Grafik uzgodnij ze szkołą i kadrami.

Twój następny krok  Przygotuj plan pierwszego tygodnia. Wpisz zadania, osobę prowadzącą i termin krótkiej rozmowy o postępach.

Podstawy i pomoc: źródła 1–3 oraz 6–8.

---

# Porozmawiaj ze szkołą online

Zapytaj o konsultację wirtualną, zanim podejmiesz decyzję o zatrudnieniu.

Rozmowa przez internet pozwala omówić warunki w Twojej firmie bez dojazdu. Możesz dołączyć osobę, która ma szkolić ucznia, lub pracownika kadr. Nie musisz mieć już gotowego kompletu dokumentów.

## Co warto ustalić podczas rozmowy

- Czy zawód i możliwości firmy pasują do programu szkoły.

- Jakie kwalifikacje instruktora i warunki stanowiska trzeba sprawdzić.

- Jak przygotować umowę, budżet i ochronę małoletnich.

- Gdzie zweryfikować refundację, dokumenty oraz przypadki szczególne.

## Przygotuj trzy informacje

Podaj zawód, miejscowość i planowaną liczbę miejsc. Zapisz pytania, które powstrzymują Cię przed decyzją. Na wstępnym spotkaniu opisuj sytuacje bez danych osobowych uczniów.

## Tak możesz rozpocząć kontakt

„Chcę sprawdzić możliwość nauki zawodu w mojej firmie. Interesuje mnie zawód … i … miejsc. Czy możemy umówić konsultację online?”

Na zakończenie poproś o krótką listę następnych kroków: co zrobić, kto za to odpowiada i do kiedy. Kwestie wymagające oceny kadr, BHP lub urzędu skieruj do właściwej osoby.

Zapytaj o konsultację online

[kontakt@zsz5.edupage.org](mailto:kontakt@zsz5.edupage.org)

Napisz, aby ustalić termin i sposób połączenia. Konsultacja nie oznacza przyznania refundacji ani potwierdzenia wszystkich warunków zatrudnienia.

---

# Sprawdź i zrób pierwszy krok

## Przed decyzją odpowiedz sobie

- Kto będzie uczył i czy ma wymagane kwalifikacje?

- Czy firma ma czas, budżet i bezpieczne stanowisko?

- Czy ustaliliśmy ze szkołą podział zadań?

- Czy zespół wie, jak chronić ucznia i reagować?

## Źródła i pomoc

[1  PIP — zatrudnianie młodocianych](https://www.pip.gov.pl/dla-pracodawcow/porady-prawne/zatrudnianie-pracownikow-mlodocianych)

[2  Kodeks pracy — art 190–206](https://eli.gov.pl/eli/DU/2026/1245/ogl/pol)

[3  Praktyczna nauka zawodu — kwalifikacje](https://eli.gov.pl/eli/DU/2019/391/ogl)

[4  OHP — zasady refundacji](https://ohp.pl/rozwoj-zawodowy/refundacja/zasady/)

[5  ZUS — ubezpieczenia pracownika](https://www.zus.pl/documents/10182/167561/Jestes_pracownikiem.pdf/)

[6  MS — wytyczne ochrony dzieci](https://www.gov.pl/web/sprawiedliwosc/standardy-ochrony-maloletnich---wytyczne)

[7  MS — sprawdzanie osób według art 21](https://www.gov.pl/web/sprawiedliwosc/jakie-obowiazki-wynikaja-z-art-21-ustawy-o-ochronie-maloletnich)

[8  Ustawa o ochronie małoletnich — art 21 i 22b–22c](https://eli.gov.pl/eli/DU/2026/110/ogl)

[9  Wrocław — dofinansowanie kształcenia](https://bip.um.wroc.pl/sprawa-do-zalatwienia/8373/dofinansowanie-kosztow-ksztalcenia-mlodocianych-pracownikow)

W PDF i Wordzie nazwy źródeł są aktywnymi linkami. Na stronie Ministerstwa Sprawiedliwości wybierz materiały o nauce zawodu i stażach uczniowskich.

Stan opracowania: 25.10.2026. Przewodnik pomaga przygotować pierwszy krok. Szczegółowe warunki zależą od ucznia, zawodu i firmy. Przed zatrudnieniem sprawdź aktualne przepisy oraz dokumenty właściwych instytucji.

---
