# Prosta publikacja dla pracodawców

Opracowanie redakcyjne i organizacyjne, 25.10.2026. Dokument towarzyszy ośmiostronicowej broszurze. Nie jest częścią tekstu przeznaczonego dla przedsiębiorcy.

## Co zastosowano i dlaczego

Kwerenda nie wskazuje jednego uniwersalnie „najlepszego” wzoru. Wspólne zalecenia instytucji zajmujących się prostą komunikacją pozwalają jednak wybrać praktyczne rozwiązania.

| Praktyka | Podstawa | Zastosowanie w broszurze |
| --- | --- | --- |
| Zaczynaj od potrzeby czytelnika | [GOV.UK — Identify user needs](https://guidance.publishing.service.gov.uk/writing-to-gov-uk-standards/plan-manage-content/identify-user-needs/) | Odbiorca ma zdecydować, czy i jak przygotować firmę. Pierwsza strona wyjaśnia sens i korzyści |
| Krótkie zdania, czynne czasowniki, bezpośredni zwrot | [Ministerstwo Cyfryzacji — Prosty język](https://www.gov.pl/web/cyfryzacja/prosty-jezyk) | „Sprawdź”, „ustal”, „przygotuj” zamiast „dokonaj weryfikacji” |
| Podstawy prawne po wyjaśnieniu sprawy | [MFiPR — Kierunek odbiorca](https://www.gov.pl/web/fundusze-regiony/kierunek-odbiorca) | Źródła na końcu i krótkie odwołania na stronach. Otwarcie nie zaczyna się od numerów ustaw |
| Jeden wątek w akapicie, czytelne śródtytuły | [GovPress — zasady prostego języka](https://www.gov.pl/web/redakcyjne-abc/najwazniejsze-zasady-prostego-jezyka) | Jeden krok na stronie, krótkie części i wskazanie następnej czynności |
| Nagłówki i wezwania opisujące działanie | [ONS — Plain language](https://service-manual.ons.gov.uk/content/writing-for-users/plain-language) | „Sprawdź możliwości firmy”, „Zaplanuj pierwszy miesiąc” |
| Objaśniaj fachowe pojęcia i sprawdzaj je z odbiorcą | [Department for Education — Plain Language](https://design.education.gov.uk/content-design/plain-language) | Wyjaśnienie roli instruktora i małoletniego; plan krótkiego testu z przedsiębiorcami |

To publikacja w prostym języku, nie certyfikowany tekst ETR. Nie przeprowadzono jeszcze testu z pracodawcami ani pomiaru Jasnopisem. Czytelności nie sprowadzamy do liczby słów w zdaniu: warunek prawny musi pozostać widoczny nawet wtedy, gdy wydłuża zdanie.

## Decyzje dotyczące treści

Korzyści przedstawiono jako możliwości: rozwój kadry, przekazywanie doświadczenia i współpraca ze szkołą. Nie wprowadzono liczb opisujących rzekome oszczędności, gwarancji zatrzymania absolwenta ani obietnicy pełnej refundacji.

Ochronę małoletnich rozdzielono na sprawdzenie osób oraz wdrożenie i stosowanie standardów. Podstawą są [wyjaśnienia Ministerstwa Sprawiedliwości](https://www.gov.pl/web/sprawiedliwosc/jakie-obowiazki-wynikaja-z-art-21-ustawy-o-ochronie-maloletnich), [wytyczne dla poszczególnych środowisk](https://www.gov.pl/web/sprawiedliwosc/standardy-ochrony-maloletnich---wytyczne) i [tekst jednolity ustawy z 2026 r.](https://eli.gov.pl/eli/DU/2026/110/ogl). Odczytano art. 22c dotyczący oceny i udostępniania standardów. Przykłady zachowań mają wyjaśniać praktykę, nie zastępować procedury interwencji.

Nie wstawiono kwartalnych kwot do krótkiej broszury, aby nie starzała się wraz z tabelą wynagrodzeń. Szczegóły finansowe pozostają w dłuższym przewodniku i rejestrze źródeł. Kontakt do konsultacji wskazany przez organizatora: kontakt@zsz5.edupage.org. Broszura zaprasza do ustalenia terminu i sposobu połączenia przez e-mail.

## Proponowana konsultacja wirtualna

Format organizacyjny do uruchomienia: 25 minut, właściciel firmy i opcjonalnie instruktor lub kadry. Nie ustalono ceny, bezpłatności ani platformy, więc nie ma takich obietnic w broszurze.

1. 5 minut — zawód, liczba miejsc, doświadczenie i pytania firmy.
2. 10 minut — instruktor, stanowisko, program i organizacja ze szkołą.
3. 5 minut — koszty, ochrona małoletnich i tematy wymagające specjalisty.
4. 5 minut — zapis kolejnych działań z odpowiedzialnością i terminem.

Korzyść dla firmy: brak dojazdu, możliwość udziału osoby szkolącej, skupienie na własnych warunkach, ustalenie kolejnych kroków. Warunek dobrego działania: prowadzący zna zakres pomocy szkoły i potrafi przekazać pytanie do kadr, BHP, OHP lub urzędu. Rozmowa nie stanowi audytu zgodności.

Do broszury dodano wskazany przez organizatora e-mail. Opcję kontaktu telefonicznego można dodać po wskazaniu numeru. Kod QR można wygenerować dopiero dla rzeczywistego adresu. Wstępny formularz powinien zbierać informacje o firmie i kontakcie; nie potrzebuje danych ucznia, badań ani dokumentów o karalności.

## Próba czytelności przed szeroką dystrybucją

Poproś 3–5 pracodawców bez doświadczenia w szkoleniu o przeczytanie broszury. Następnie zadaj pytania: „Od czego zaczniesz?”, „Jakie dwa zadania dotyczą ochrony małoletnich?”, „Co oprócz wynagrodzenia kosztuje firmę?”, „Co chcesz ustalić na konsultacji?”. Zapisz miejsca, w których szukają wyjaśnienia. Popraw treść na podstawie odpowiedzi, a nie samej deklaracji, że publikacja się podoba.

## Pliki

- `przewodnik-dla-pracodawcow.pdf` — do czytania i przekazania z kontaktem e-mail.
- `przewodnik-dla-pracodawcow.docx` — wersja edytowalna.
- `przewodnik-dla-pracodawcow.md` — treść do dalszego wykorzystania na stronie.
- `build_guide.py` — odtwarza Word i Markdown; PDF powstaje podczas renderowania Worda.

Przeprowadzono kontrolę wizualną wszystkich ośmiu stron. Publicznej strony projektu nie zmieniano i dodano jedynie podany adres do kontaktu; nie wysłano wiadomości ani nie utworzono systemu rezerwacji.
