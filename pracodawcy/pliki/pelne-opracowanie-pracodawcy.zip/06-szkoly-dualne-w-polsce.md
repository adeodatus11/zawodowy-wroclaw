# Szkoły w Polsce: uczeń i pracownik młodociany

Weryfikacja: 25.10.2026. Wybrane przykłady branżowych szkół I stopnia. Kryterium: wprost opisana umowa o pracę w celu przygotowania zawodowego, status młodocianego lub dokumenty potwierdzające organizację tej ścieżki. Nie zakładamy, że każdy uczeń i każdy zawód danej szkoły realizuje ten sam model. To wybór przykładów, nie ogólnopolski rejestr ani lista partnerów ZSZ5.

## 1. Rzemieślnicza Branżowa Szkoła I stopnia MIRiP — Kraków

Województwo: małopolskie.

Szkoła wymaga umowy o pracę w celu przygotowania zawodowego i opisuje podział tygodnia między szkołę a zakład pracy.

Co warto zobaczyć: Przejrzyste wyjaśnienie organizacji tygodnia oraz roli cechów w znalezieniu pracodawcy.

Źródło: [Opis organizacji nauki na stronie szkoły.](https://szkola.izba.krakow.pl/branzowa-szkola-i-stopnia/)

## 2. Branżowa Szkoła I stopnia nr 1 w Pomorskich Szkołach Rzemiosł im. Wiesława Szajdy — Gdańsk

Województwo: pomorskie.

Regulamin rekrutacji 2026/2027 oznacza zawody z zatrudnieniem młodocianego i wskazuje umowę o pracę w celu przygotowania zawodowego.

Co warto zobaczyć: Rozróżnienie ścieżek: fotograf jest oferowany zarówno jako młodociany pracownik, jak i w warsztatach szkolnych. Potwierdzenie dotyczy ścieżek pracowniczych.

Źródło: [Regulamin rekrutacji 2026/2027, część I — oferta szkoły branżowej.](https://psr.gda.pl/wp-content/uploads/2026/02/Regulamin-rekrutacji-2026_2027.pdf)

## 3. Branżowa Szkoła I stopnia nr 7 w Zespole Szkół Łączności — Gliwice

Województwo: śląskie.

Regulamin 2026/2027 wymaga znalezienia zakładu pracy, przewiduje deklarację zatrudnienia młodocianego i opisuje właściwą ścieżkę egzaminu.

Co warto zobaczyć: Czytelne połączenie rekrutacji, pracodawcy i późniejszego egzaminu.

Źródło: [Regulamin rekrutacji 2026/2027, § 8.](https://zsl.gliwice.pl/regulamin-rekrutacji-w-branzowej-szkole-i-stopnia-nr-7/)

## 4. Branżowa Szkoła Rzemieślnicza I stopnia — Biała Podlaska

Województwo: lubelskie.

Informator kuratorium na 2026/2027 wprost opisuje umowę o pracę, status młodocianego pracownika i wynagrodzenie.

Co warto zobaczyć: Prosta informacja o tym, że uczeń łączy naukę z zatrudnieniem u pracodawcy.

Źródło: [Oficjalny informator Kuratorium Oświaty, 2026/2027.](https://kuratorium.lublin.pl/informator.php?id=29316)

## 5. Branżowa Szkoła I stopnia w Zespole Szkół Usługowych — Ostrów Wielkopolski

Województwo: wielkopolskie.

Informator szkoły wskazuje zawarcie umowy o pracę w celu przygotowania zawodowego i podział dni między szkołę a pracodawcę.

Co warto zobaczyć: Wspólny informator dla kandydata, ucznia i pracodawcy.

Źródło: [Informator dostępny w witrynie szkoły; nie traktujemy go jako potwierdzenia aktualności wszystkich stawek i przepisów.](https://zsu.osw.pl/Portals/zsu1/Informacje%20dla%20kandydatow%20do%20szkoly%20branzowej%20I%20stopnia.pdf)

## 6. Branżowa Szkoła I stopnia w Zespole Szkół nr 1 — oddział wielozawodowy — Lubin

Województwo: dolnośląskie.

Oddział opisano jako kształcenie pracowników młodocianych. Warunkiem przyjęcia jest umowa z pracodawcą na okres nauki.

Co warto zobaczyć: Szkoła deklaruje pomoc w znalezieniu pracodawcy i wskazuje szkolną bazę oraz cech.

Źródło: [Opis oddziału wielozawodowego na stronie szkoły.](https://zs1.lubin.pl/szkoly/branzowa-szkola-i-stopnia/oddzial-wielozawodowy)

## 7. Branżowa Szkoła I stopnia nr 2 w Zespole Szkół nr 2 CKU — Kluczbork

Województwo: opolskie.

Strona rekrutacji udostępnia bazę pracodawców 2026/2027, deklarację pracodawcy i umowę w celu przygotowania zawodowego. Dział Pracodawca opisuje młodocianych.

Co warto zobaczyć: Baza firm, dokumenty i programy praktycznej nauki zawodu w jednym serwisie.

Źródło: [Rekrutacja 2026/2027 i dział Pracodawca.](https://zsp2kluczbork.edupage.org/a/rekrutacja)

