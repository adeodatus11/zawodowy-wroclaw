# Kwerenda: zatrudnienie młodocianego z perspektywy pracodawcy

Data dostępu i opracowania: **25.10.2026**. Zakres: Polska, z lokalną ścieżką dla Wrocławia i Dolnego Śląska. Kwerenda internetowa oraz przegląd istniejącego repozytorium; bez kontaktowania się z instytucjami.

## 1. Metoda i wynik

Wyszukano materiały według pytań przedsiębiorcy: warunki zatrudnienia, kwalifikacje instruktora, umowa, czas pracy, BHP, ZUS, wynagrodzenie, refundacja OHP, dofinansowanie gminne, egzamin i współpraca ze szkołą. Pierwszeństwo mają przepisy i publikacje instytucji odpowiedzialnej za dany obszar. Data indeksowania strony nie potwierdza aktualności jej treści.

Poniższy rejestr odróżnia odczytaną treść, wynik dostępny w indeksie wyszukiwarki i materiały odrzucone. Nie jest to potwierdzenie uprawnień konkretnej firmy ani kompletna analiza wszystkich nowelizacji i przepisów przejściowych.

## 2. Rejestr materiałów

| ID | Instytucja i materiał | Zastosowanie | Ocena / sposób odczytu |
| --- | --- | --- | --- |
| S01 | [PIP: Zatrudnianie pracowników młodocianych](https://www.pip.gov.pl/dla-pracodawcow/porady-prawne/zatrudnianie-pracownikow-mlodocianych) | Mapa obowiązków, umowa, organizacja pracy | Odczyt strony. Przydatna struktura, ale niektóre odesłania i fragmenty wymagają korekty według ustaw; zob. rozbieżności |
| S02 | [PIP: Pracownik młodociany — broszura](https://www.pip.gov.pl/files/127/Dla-pracodawcow/770/Pracownik.pdf) | Materiał pomocniczy do biblioteki | Fragmenty w indeksie, nie pełny audyt broszury; przed podlinkowaniem do druku sprawdzić datę i całość |
| S03 | [Kodeks pracy, tekst jednolity 2026, poz. 1245](https://eli.gov.pl/eli/DU/2026/1245/ogl/pol) | Art. 190–206, zwłaszcza czas pracy i urlopy | Odczyt odpowiednich fragmentów PDF; tekst uwzględnia stan na 27.08.2026 |
| S04 | [Przygotowanie zawodowe i wynagradzanie — akt bazowy](https://eli.gov.pl/eli/DU/1996/278/ogl) i [tekst jednolity 2018](https://eli.gov.pl/api/acts/DU/2018/2010/text.html) | Organizacja nauki, zawiadomienia, egzaminy, mechanizm płacy | Akt bazowy stosować ze zmianami; nie traktować tekstu 2018 jako aktualnej tabeli płac |
| S05 | [Zmiana wynagrodzeń: Dz.U. 2023 poz. 1348](https://eli.gov.pl/api/acts/DU/2023/1348/text.html) | Minima 8%, 9%, 10% i 7% przy przyuczeniu | Odczyt pełnego krótkiego aktu; obowiązuje od 1.09.2023 |
| S06 | [Praktyczna nauka zawodu: Dz.U. 2019 poz. 391](https://eli.gov.pl/api/acts/DU/2019/391/text.html) | Rodzaje współpracy i kwalifikacje instruktorów, zwłaszcza § 10 | Odczyt HTML; do kwalifikacji konkretnej osoby potrzebna analiza dokumentów |
| S07 | [Prace wzbronione: Dz.U. 2023 poz. 1240](https://eli.gov.pl/api/acts/DU/2023/1240/text.html) | Ocena stanowiska i ograniczone wyjątki dla przygotowania zawodowego | Odczyt przepisów; załączniki dopasować do konkretnego zawodu i stanowiska |
| S08 | [ZUS: Jesteś pracownikiem? Poznaj swoje ubezpieczenia](https://www.zus.pl/documents/10182/167561/Jestes_pracownikiem.pdf/) | Ubezpieczenia, ZUA, RCA/RSA, wyrejestrowanie | Odczyt treści w indeksie PDF; ogólna informacja dla pracowników, nie aktualny kalkulator listy płac |
| S09 | [ZUS: okresy podlegania ubezpieczeniom społecznym](https://bip.zus.pl/pl/web/guest/pracujacy/system-ubezpieczen-spolecznych-w-polsce/okresy-podlegania-ubezpieczeniom-spolecznym) | Potwierdzenie obowiązkowych ubezpieczeń pracownika | Odczyt indeksu, materiał z 15.04.2021; wąski zakres zastosowania |
| S10 | [ZUS: FAQ zmian od 2022 r.](https://psz.zus.pl/pl/web/guest/o-zus/o-nas/programy-transformacji-cyfrowej-zus/zmiany-od-2022-r./faq) | Dlaczego obliczenie składki zdrowotnej młodocianego nie jest prostym „9% od brutto” | Odczyt indeksu; punkt wyjścia do weryfikacji kadrowej, nie samodzielna instrukcja rozliczeń na 2026 |
| S11 | [OHP: zasady refundacji](https://ohp.pl/rozwoj-zawodowy/refundacja/zasady/) | Warunki refundacji i kwalifikacje szkolących | Indeks dostępny; bezpośredni odczyt zwracał błąd. Podstawę terminów sprawdzono w S13 |
| S12 | [OHP: komunikaty](https://www.ohp.pl/rozwoj-zawodowy/refundacja/komunikaty) | Dostępność środków i nowe formularze | Indeks zawiera komunikat o dodatkowych środkach na 2026; nie dowodzi przyznania wsparcia konkretnej firmie |
| S13 | [Refundowanie wynagrodzeń: Dz.U. 2025 poz. 1632](https://eli.gov.pl/eli/DU/2025/1632/ogl) | Aktualny tryb wnioskowania i umowy OHP | Zweryfikowano datę wejścia 1.12.2025 i treść m.in. § 2 ust. 8, § 3 ust. 6–7 w oficjalnym PDF |
| S14 | [Ustawa o rynku pracy i służbach zatrudnienia: Dz.U. 2025 poz. 620](https://isap.sejm.gov.pl/isap.nsf/download.xsp/WDU20250000620/T/D20250620L.pdf) | Art. 348–350, podstawa refundacji OHP | Odczyt fragmentu art. 348; w szczegółowej instrukcji uwzględnić także warunki art. 349 |
| S15 | [Prawo oświatowe: Dz.U. 2026 poz. 820](https://eli.gov.pl/eli/DU/2026/820/ogl) | Art. 120a i 122: współpraca ze szkołą i dofinansowanie | Odczyt tekstu ujednoliconego z 16.09.2026, strony 186 oraz 190–193; wykryta rozbieżność odesłań w art. 122 |
| S16 | [Wrocław: dofinansowanie kosztów kształcenia](https://bip.um.wroc.pl/sprawa-do-zalatwienia/8373/dofinansowanie-kosztow-ksztalcenia-mlodocianych-pracownikow) | Lokalna procedura, zawiadomienie, wniosek i urząd | Obszerny odczyt indeksu; bezpośredni odczyt zwracał 502. Wydział Finansów Oświatowych; właściwość zależy od zamieszkania młodocianego |
| S17 | [GUS: przeciętne wynagrodzenie w II kwartale 2026](https://stat.gov.pl/sygnalne/komunikaty-i-obwieszczenia/lista-komunikatow-i-obwieszczen/komunikat-w-sprawie-przecietnego-wynagrodzenia-w-drugim-kwartale-2026-r-%2C271%2C53.html) | Podstawa przykładowej tabeli płac: 9233,13 zł | Odczyt indeksu komunikatu z 10.08.2026; używać treści komunikatu, wyniki wyszukiwania miały niespójne etykiety tytułów |
| S18 | [MEN: kształcenie młodocianych pracowników](https://www.gov.pl/web/nauka/ksztalcenie-mlodocianych-pracownikow) | Program, dni praktyki i monitorowanie uzgadniane ze szkołą | Odczyt indeksu; artykuł pomocniczy, potwierdzony art. 120a |
| S19 | [Dolnośląska Izba Rzemieślnicza: kurs pedagogiczny](https://izba.wroc.pl/kurs-pedagogiczny/) | Lokalna ścieżka przygotowania instruktora | Odczyt indeksu; cen i terminów nie potwierdzono, kwalifikacje weryfikować według S06 |
| S20 | [Dolnośląska Izba Rzemieślnicza: egzamin czeladniczy](https://izba.wroc.pl/egzamin-czeladniczy/) | Dokumentacja i organizacja egzaminu rzemieślniczego | Odczyt indeksu; opłaty i terminy konkretnej sesji do potwierdzenia |
| S21 | [RPD: wyjaśnienia MEN o standardach u pracodawców](https://brpd.gov.pl/2024/08/09/bez-zmian-w-organizacji-praktyk-zawodowych/) | Standardy ochrony małoletnich w miejscu kształcenia | Odczyt indeksu; ważny element gotowości firmy |
| S22 | [Ministerstwo Sprawiedliwości: obowiązki z art. 21](https://www.gov.pl/web/sprawiedliwosc/jakie-obowiazki-wynikaja-z-art-21-ustawy-o-ochronie-maloletnich) | Weryfikacja osób wykonujących zadania związane z edukacją lub opieką nad małoletnimi | Odczyt indeksu; weryfikacja personelu jest odrębna od przyjęcia standardów |
| S23 | [Ministerstwo Sprawiedliwości: wyjaśnienia do ustawy](https://www.gov.pl/web/sprawiedliwosc/pytania-do-ustawy-o-ochronie-dzieci2) | Wyjaśnienie różnicy pomiędzy standardami a procedurą sprawdzania | Odczyt indeksu; dobór obowiązków według rzeczywistej roli danej osoby |

## 3. Najważniejsze ustalenia dla koncepcji

**Model współpracy trzeba nazwać precyzyjnie.** Przepisy dopuszczają zajęcia u pracodawcy zarówno w ramach zatrudnienia młodocianego, jak i umowy szkoły z firmą. Dział ma koncentrować się na pierwszej ścieżce. Sam fakt, że uczeń pojawia się w firmie, nie określa jeszcze jego statusu. Źródło: S06.

**ZUS jest obowiązkiem pracodawcy także przy zatrudnieniu ucznia.** Obowiązkowe ubezpieczenie chorobowe pracownika nie może być przedstawiane jako dobrowolne. Status ucznia nie znosi obowiązków wynikających z umowy o pracę. Źródła: S08–S09.

**Dwa instrumenty finansowania wymagają dwóch instrukcji.** Refundacja OHP dotyczy określonych wynagrodzeń i składek; dofinansowanie gminne dotyczy kształcenia. Nie sumować ich w reklamowe „zatrudnienie za zero”. Źródła: S13–S16.

**BHP musi uwzględniać zawód i stanowisko.** Ogólna lista nie przesądzi, czy młodociany może obsługiwać konkretną maszynę lub wykonywać daną czynność. Wyjątki od zakazów są ograniczone wiekiem, celem nauki i warunkami ochrony. Źródło: S07.

## 4. Rozbieżności i materiały do ograniczonego wykorzystania

| Problem | Co ustalono | Decyzja redakcyjna |
| --- | --- | --- |
| Stare PDF na domenie ZUS | [Poradnik z 2013 r.](https://www.zus.pl/documents/10182/167670/porad1z12032013.pdf/e546b531-12af-4722-aa64-9fd7305c7be1?t=1435835730674) wskazuje wiek 16 lat i stawki 4/5/6% | Odrzucić jako aktualny poradnik dla firm |
| Starsza broszura „Prawo pracy. Pierwsze kroki” | [Plik na stronie ZUS](https://www.zus.pl/documents/10182/167529/Broszura_Prawo_pracy_Pierwsze_kroki.pdf/f9add854-0416-43a3-b45a-7c2295fe9cec?t=1435324711043) mówi o gimnazjum i progu 16 lat | Nie włączać do rekomendowanego pakietu |
| Odesłania w poradzie PIP | S01 zawiera m.in. rozporządzenie o pracach wzbronionych z 2004 r. i starsze odesłanie dotyczące instruktorów | Podstawą aktualnych szczegółów są S06–S07; poradę PIP traktować selektywnie |
| Mieszanie prac lekkich i nauki zawodu | Różne limity czasu pracy bywają podawane w jednym materiale | W przewodniku oddzielne ścieżki; główny grafik opierać na art. 202–203 |
| Dofinansowanie: 75/25 a 100% | Uzupełniająca weryfikacja potwierdziła art. 23 ustawy z 21.05.2025 r., Dz.U. poz. 769, zmieniający art. 122 ust. 3 od 13.07.2025 r. | Rozstrzygnięte: przy nauce zawodu przystąpienie do właściwego egzaminu i pozostałe warunki uprawniają do właściwego limitu 100%; przy krótszym okresie proporcja. Nie powielać 75/25. Szczegóły w uzupełnieniu kwerendy |
| Stary kalendarz OHP | W internecie krążą instrukcje oparte na wcześniejszych przepisach | Przyjąć punkt wyjścia z S13: wniosek w roku zawarcia umowy; późniejszy wniosek może ograniczyć początek refundacji do roku złożenia |
| Kwoty bez terminu obowiązywania | W komercyjnych tabelach znaleziono również błędne daty okresów | Liczyć z GUS i rozporządzenia; nie kopiować tabel wtórnych |
| Dostępność lokalnych stron | S11 i S16 nie otworzyły się bezpośrednio, choć treść była dostępna w indeksie | Przed publikacją odtworzyć dostęp, sprawdzić druki i właściwy kanał złożenia |

## 5. Co jeszcze trzeba ustalić w etapie wdrożenia

- Dolnośląski wykaz rozstrzygnięto: uchwała 4075/VII/26, poz. 2156, 49 zawodów; odczytano urzędowy PDF. Do dalszego ustalenia pozostaje komórka obsługująca daną firmę i bieżący formularz lokalnego CEiPM.
- Warunki deklaracji dalszego zatrudnienia w umowie refundacyjnej, limity i przesłanki odmowy. Nie utożsamiać zobowiązania firmy wobec OHP z obowiązkiem absolwenta pozostania w firmie.
- Kody zgłoszeniowe i zmiany po osiągnięciu pełnoletności, FP/FS i FGŚP, stopa wypadkowa, składka zdrowotna, ulga PIT dla młodych oraz przypadki niepełnego miesiąca i choroby — z kadrami i aktualnymi materiałami ZUS/KAS.
- Aktualny formularz właściwej gminy i warunki konkretnego rocznika. Regułę przystąpienia oraz mechanizm waloryzacji wyjaśnia uzupełnienie; właściwość zależy od zamieszkania ucznia.
- Różnice egzaminu czeladniczego i zawodowego, opłaty, harmonogram OKE/izby oraz zasady przy zmianie statusu pracodawcy.
- Zawody i możliwości współpracy ZSZ nr 5, pomoc szkoły, terminy spotkań i osoba obsługująca firmy.
- Ścieżki szczególne: kandydat poniżej 15 lat, cudzoziemiec, niepełnosprawność, ciąża, zmiana pracodawcy, kontynuacja po 18. roku życia. Każda wymaga osobnej, sprawdzonej instrukcji, zanim otrzyma automatyczną odpowiedź w FAQ.

## 6. Utrzymanie rejestru

Przy kolejnych aktualizacjach zapisywać: ID, URL, instytucję, tytuł, datę publikacji lub stan prawny, datę odczytu, zakres wykorzystania, właściciela tematu, termin następnej kontroli i listę miejsc, w których wykorzystano informację. Wykrycie sprzeczności powinno aktualizować równocześnie stronę, plik do druku i FAQ.
